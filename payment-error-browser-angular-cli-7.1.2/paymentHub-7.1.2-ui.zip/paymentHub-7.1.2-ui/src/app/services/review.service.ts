import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { hostName } from '../shared/hostName';

@Injectable({
  providedIn: 'root'
})
export class ReviewService {

  serviceUrl = "";
  host: string;
  revieweUrl = "pendingApprovalErrorMessages";
  reviewUrl = "reviewPendingRecords";
  reviewJson = {};
  constructor(private http: HttpClient) { 
    this.host = hostName;
    this.revieweUrl = this.host + this.revieweUrl;
    this.reviewUrl = this.host + this.reviewUrl;
  }
  
  // Returns the Observable for the review messages
  getReviewMessages(pageNo, perPage) {
    this.serviceUrl = this.revieweUrl + `?page=${pageNo}&size=${perPage}&sort=offsetId`;
    return this.http.get(this.serviceUrl);
  }

  // Updates the message with either approve or reject status
  reviewMessages(messageList, status) {
    this.reviewJson = {
      "list": messageList,
      "status": status
    }
    return this.http.put(this.reviewUrl,this.reviewJson);
  }
}