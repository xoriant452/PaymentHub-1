package com.citi.payhub.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

@Component
public class MQueueConsumerService {

	@Autowired
	private KafkaTransformProducerService kafkaProducerService;

	@Value("${spring.kafka.consume.bootstrapServer}")
	private String bootstrapServer;

	@Value("${spring.kafka.consume.topic}")
	private String topic;

	@Value("${spring.kafka.consumergroup.id1}")
	private String groupId;

	@Value("${spring.kafka.produce.topic}")
	private String producerTopic;

	@JmsListener(destination = "${spring.activemq.queueName}",containerFactory = "myFactory")
	public void receiveQueue(String text) {
		System.out.println(text);
		kafkaProducerService.pushMessageToKafka(producerTopic, text, groupId);
	}

}
