package com.citi.payhub.util;

public class ConstantUtils {

	public static final String KAFKA="kafka";
	public static final String MQUEUE="mqueue";
	public static final String RESTAPI="restapi";
	public static final String FILE="file";
	public static final String BLANKSTR="";
	
}
