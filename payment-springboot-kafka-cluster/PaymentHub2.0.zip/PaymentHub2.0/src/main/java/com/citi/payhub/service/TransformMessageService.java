package com.citi.payhub.service;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.citi.payhub.module.TransformMessage;

@Component
public class TransformMessageService {

	private static Logger logger = LogManager.getLogger(KafkaTransformConsumerService.class);
	
	@Value("${payhub.transform.message.jar.path}")
	private String transformMessageJarPath;

	@Value("${payhub.transform.method.name}")
	private String transformMethodName;
	
	
	private String  getTransformMsgInstance(String message) throws Exception {
		URL[] classLoaderUrls = new URL[]{new URL("file:///"+transformMessageJarPath)};
		
		// Create a new URLClassLoader 
		URLClassLoader urlClassLoader = URLClassLoader.newInstance(classLoaderUrls,TransformMessage.class.getClassLoader());
		// Load the target class
		Class<?> beanClass = Class.forName("com.transformed.TransformMessageImpl", true, urlClassLoader);
        // Create a new instance from the loaded class
        Constructor<?> constructor = beanClass.getConstructor();
        Object  beanObj =  constructor.newInstance();
        // Getting a method from the loaded class and invoke it
       Method method = beanClass.getDeclaredMethod(transformMethodName,String.class);
        String str=(String) method.invoke(beanObj,message);
        System.out.println(str);
			return str;
	}
	
	public String sendTransformMessageFirst(String message) {
		String transStr="";
		try {
			transStr = getTransformMsgInstance(message);
		} catch (Exception e) {
			e.printStackTrace();
		}
		logger.info("Received Message1 ={}\n", transStr);
		return transStr;
	}
	public String sendTransformMessageSecond(String message){
		String transStr=message.replace("{", "<").replace("}", ">");
		//logger.info("Received Message2 ={}\n", transStr);
		return transStr;
	}
	
	
}
