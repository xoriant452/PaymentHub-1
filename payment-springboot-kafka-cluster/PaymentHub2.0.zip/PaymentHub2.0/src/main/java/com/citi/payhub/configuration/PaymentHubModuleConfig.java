package com.citi.payhub.configuration;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Conditional;
import org.springframework.context.annotation.Configuration;

import com.citi.payhub.condition.FileConfigCondition;
import com.citi.payhub.condition.KafkaConfigCondition;
import com.citi.payhub.condition.KafkaTransformCondition;
import com.citi.payhub.condition.MessagingQueueConfigCondition;
import com.citi.payhub.condition.MessagingQueueTransformCondition;
import com.citi.payhub.condition.RESTConfigCondition;
import com.citi.payhub.service.KafkaTransformConsumerService;
import com.citi.payhub.service.KafkaConsumerModuleService;

@Configuration
public class PaymentHubModuleConfig {

	private static Logger logger = LogManager.getLogger(PaymentHubModuleConfig.class);
	
	@Autowired
	KafkaConsumerModuleService kafkaConsumerService;
	
	@Autowired
	KafkaTransformConsumerService kafkaTransformConsumerService;
	@Autowired
    ApplicationContext context;
	
	@Bean
	@Conditional(value = KafkaConfigCondition.class)
	public void kafkaConsumerModuleConfig(){
		logger.info("I am in receiveMessage");
		    	kafkaConsumerService.receiveMessage();
	}
	
	@Bean
	@Conditional(value = KafkaTransformCondition.class)
	public void kafkaTransformConfig(){
		logger.info("I am in receiveProducedMessagesForKafka");
		kafkaTransformConsumerService.receiveProducedMessagesForKafka();
	}

	@Bean
	@Conditional(value = MessagingQueueConfigCondition.class)
	public void mQueueConfig() {
		logger.info("I am in MessagingQueueUtil");
	
	}

	@Bean
	@Conditional(value = MessagingQueueTransformCondition.class)
	public void mQueueTransformConfig() {
		logger.info("I am in MessagingQueueTransformCondition");
		kafkaTransformConsumerService.receiveProducedMessagesForMQueue();
		
	}

	@Bean
	@Conditional(value = RESTConfigCondition.class)
	public void restConfig() {
		logger.info("I am in RESTUtil");
	}

	@Bean
	@Conditional(value = FileConfigCondition.class)
	public void fileConfig() {
		logger.info("I am in FileUtil");
	}

}
