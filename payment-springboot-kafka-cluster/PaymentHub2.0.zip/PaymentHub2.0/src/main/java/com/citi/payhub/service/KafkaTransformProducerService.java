package com.citi.payhub.service;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.apache.kafka.clients.consumer.OffsetAndMetadata;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.TopicPartition;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.citi.payhub.configuration.KafkaProducerConfig;


/**
 * Producer Service
 * 
 * @author Yogesh Mohite
 * @CreationDate 26/10/2018
 * @version 1.0
 */
@Component
public class KafkaTransformProducerService {

	private Logger logger = LogManager.getLogger(KafkaTransformProducerService.class);
	
	@Value("${spring.kafka.transform.produce.bootstrapServer}")
	String bootstrapServer;
	
	@Autowired
	KafkaProducerConfig kafkaProducerConfig;
	
	private Producer<Long, String> producer;
	
	@PostConstruct
	public void initProducer() {
		producer = kafkaProducerConfig.getProducer(bootstrapServer);
		producer.initTransactions();
	}
	

	/**
	 * Method reprocess the error message which is come from Error message topic.
	 * @param topic
	 * @param errorMessage
	 */
	public void pushMessageToKafka(String topic, String message,String groupId) {
			/*Map<TopicPartition, OffsetAndMetadata> groupCommit = new HashMap<TopicPartition, OffsetAndMetadata>();
			groupCommit.put(new TopicPartition(topic, 0), new OffsetAndMetadata(offset + 1, null));*/
		try {
			producer.beginTransaction();
			final ProducerRecord<Long, String> record = new ProducerRecord<>(topic, message);
			producer.send(record).get();
			//producer.sendOffsetsToTransaction(groupCommit, groupId);
			producer.commitTransaction();
		} catch (Exception e) {
			producer.abortTransaction();
			logger.error(e);
		} 
	}

}
