package com.citi.payhub.configuration;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.serialization.LongDeserializer;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

/**
 * Kafka Consumer Config
 * 
 * @author Yogesh Mohite
 * @CreationDate 26/11/2018
 * @version 1.0
 */
@Lazy
@Component
public class KafkaConsumerConfig {

	private static Logger logger = LogManager.getLogger(KafkaConsumerConfig.class);

	@Value("${spring.kafka.isolation}")
	String isolationLevel;

	@Value("${spring.kafka.autooffset}")
	String autoOffsetReset;

	@Value("${spring.kafka.autocommit}")
	String autoCommit;

	@PostConstruct
	private Map<String, Object> setBootStrapProperties() {
		Map<String, Object> props = new HashMap<>();
		props.put(ConsumerConfig.ISOLATION_LEVEL_CONFIG, isolationLevel);
		props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, autoOffsetReset);
		props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, autoCommit);
		props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, LongDeserializer.class.getName());
		props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
		return props;
	}
	
	public Consumer<Long, String> createConsumer(String topic, String bootstrapServer,String groupId) {
		Map<String, Object> props = setBootStrapProperties();
		props.put(ConsumerConfig.GROUP_ID_CONFIG, groupId);
		props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServer);
		Consumer<Long, String> consumer = new KafkaConsumer<>(props);
		consumer.subscribe(Collections.singletonList(topic));
		return consumer;
	}

}
