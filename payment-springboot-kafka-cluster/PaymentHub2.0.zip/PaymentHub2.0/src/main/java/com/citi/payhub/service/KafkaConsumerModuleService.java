package com.citi.payhub.service;

import java.time.Duration;

import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

import com.citi.payhub.configuration.KafkaConsumerConfig;

/**
 * @author Yogesh Mohite
 *
 */
@Lazy
@Component
public class KafkaConsumerModuleService {


	@Autowired
	private KafkaConsumerConfig kafkaConsumerConfig;

	@Value("${spring.kafka.consume.bootstrapServer}")
	private String bootstrapServer;

	@Value("${spring.kafka.consume.topic}")
	private String topic;

	@Value("${spring.kafka.consumergroup.id1}")
	private String groupId;

	@Value("${spring.kafka.produce.topic}")
	private String producerTopic;

	@Autowired
	private KafkaTransformProducerService kafkaProducerService;

	public void receiveMessage() {
		Consumer<Long, String> consumer = kafkaConsumerConfig.createConsumer(topic, bootstrapServer, groupId);
		new Thread(() -> {
		while (true) {
			ConsumerRecords<Long, String> records = consumer.poll(Duration.ofMillis(0));
			for (ConsumerRecord<Long, String> record : records) {
				/*logger.info("Received Message topic ={}, partition ={}, offset = {}, key = {}, value = {}\n",
						record.topic(), record.partition(), record.offset(), record.key(), record.value());*/
				//kafkaProducerService.pushMessageToKafka(producerTopic, record.value(), groupId, record.offset());
				kafkaProducerService.pushMessageToKafka(producerTopic, record.value(), groupId);
			}
			consumer.commitSync();
		}
		}).start();
	}
}
