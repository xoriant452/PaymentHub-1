package com.citi.payhub.service;

public class MessagingQueueModuleService {

}
