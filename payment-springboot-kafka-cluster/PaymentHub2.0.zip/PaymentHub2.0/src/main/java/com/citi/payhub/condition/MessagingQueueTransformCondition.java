package com.citi.payhub.condition;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.context.annotation.Condition;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.type.AnnotatedTypeMetadata;

import com.citi.payhub.util.ConstantUtils;

@PropertySource("application.properties")
public class MessagingQueueTransformCondition implements Condition{

	private static Logger logger = LogManager.getLogger(MessagingQueueTransformCondition.class);
	
	@Override
	public boolean matches(ConditionContext context, AnnotatedTypeMetadata metadata) {
		String config=context.getEnvironment().getProperty("payhub.transform.config");
		if(null!=config && !ConstantUtils.BLANKSTR.equalsIgnoreCase(config)) {
			logger.info("I am in Message");
			return config.equalsIgnoreCase(ConstantUtils.MQUEUE);
		}
		return false;
	}

}
