package com.citi.payhub.service;

import javax.jms.Queue;

import org.apache.activemq.command.ActiveMQQueue;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;

@Component
public class MQueueProducerService {

	
	@Autowired
	JmsTemplate jmsTemplate;

	@Autowired
	TransformMessageService transformMessageService;
	
	@Value("${spring.activemq.transform.queue1}")
	private String transformQueue1;
	
	@Value("${spring.activemq.transform.queue2}")
	private String transformQueue2;

	
	private Queue getQueue(String queue) {
		return new ActiveMQQueue(queue);
	}

	public void publishMessageToQueue(String message) {
		publishTransMesgInQueue(transformQueue1,  transformMessageService.sendTransformMessageFirst(message)); 
		publishTransMesgInQueue(transformQueue2,  transformMessageService.sendTransformMessageSecond(message)); 
	}
	
	private String publishTransMesgInQueue(String queue,String message) {
		jmsTemplate.convertAndSend(getQueue(queue),message);
		return "Message sent successfully";
	}
	
}
