package com.citi.payhub.module;

public interface TransformMessage {
	public String getTransformedMessage(String message);
}
