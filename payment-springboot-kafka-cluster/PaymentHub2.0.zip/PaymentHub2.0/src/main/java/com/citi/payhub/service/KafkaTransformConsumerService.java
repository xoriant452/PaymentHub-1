package com.citi.payhub.service;

import java.time.Duration;

import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

import com.citi.payhub.configuration.KafkaConsumerConfig;

@Lazy
@Component
public class KafkaTransformConsumerService {
	private static Logger logger = LogManager.getLogger(KafkaTransformConsumerService.class);
	
	@Autowired
	private KafkaConsumerConfig kafkaConsumerConfig;
	
	@Value("${spring.kafka.transform.consume.bootstrapServer}")
	private String bootstrapServer;
	
	@Value("${spring.kafka.produce.topic}")
	private String topic;
	
	@Value("${spring.kafka.consumergroup.id2}")
	private String groupId;
	
	@Value("${spring.kafka.produce.topic}")
	private String producerTopic;
	 
	@Autowired
	private KafkaProducerModuleService kafkaProducerModuleService;
	
	@Autowired
	private MQueueProducerService mQueueProducerService;
	
	public void receiveProducedMessagesForKafka() {
		Consumer<Long,String> consumer=kafkaConsumerConfig.createConsumer(topic,bootstrapServer,groupId);
		//new Thread(() -> {
		while(true) {
			ConsumerRecords<Long,String> records = consumer.poll(Duration.ofMillis(100));
            for (ConsumerRecord<Long,String> record : records) {
            	logger.info("");
                //logger.info("Received Message topic ={}, partition ={}, offset = {}, key = {}, value = {}\n", record.topic(), record.partition(), record.offset(), record.key(), record.value());
                String message=record.value();
            	kafkaProducerModuleService.pushMessageToKafka(message,topic,record.offset(),groupId);
               }
            consumer.commitSync();
		}
		//}}).start();
      }
	
	public void receiveProducedMessagesForMQueue() {
		Consumer<Long,String> consumer=kafkaConsumerConfig.createConsumer(topic,bootstrapServer,groupId);
		//new Thread(() -> {
		while(true) {
		ConsumerRecords<Long,String> records = consumer.poll(Duration.ofMillis(100));
            for (ConsumerRecord<Long,String> record : records) {
                //logger.info("Received Message topic ={}, partition ={}, offset = {}, key = {}, value = {}\n", record.topic(), record.partition(), record.offset(), record.key(), record.value());
                String message=record.value();
                mQueueProducerService.publishMessageToQueue(message);
            	consumer.commitSync();
               }
		}
	//	}}).start();
      }

	
}
