package com.citi.payhub.pub.kafka;

import static com.citi.payhub.util.constant.ConstantUtils.INSTANCE_ERROR_CONNECT_POINT_NAME;
import static com.citi.payhub.util.constant.ConstantUtils.INSTANCE_PRODUCER_BOOTSTRAPSERVER;
import static com.citi.payhub.util.constant.ConstantUtils.INSTANCE_PRODUCER_NAME;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutionException;

import javax.annotation.PostConstruct;

import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.citi.payhub.pub.config.KafkaProducerConfig;

/**
 * 
 * @author Yogesh Mohite
 * @CreationDate 20/12/2018
 * @version 1.0
 */
@Lazy
@Component
public class KafkaProducer {

	private Logger logger = LogManager.getLogger(KafkaProducer.class);

	@Autowired
	Environment environment;

	@Autowired
	private KafkaProducerConfig kafkaProducerConfig;

	private Producer<Long, String> producer;

	private List<String> topicList = null;

	@PostConstruct
	public void initProducer() {
		producer = kafkaProducerConfig.getProducer(environment.getProperty(INSTANCE_PRODUCER_BOOTSTRAPSERVER));
		topicList = Arrays.asList(environment.getProperty(INSTANCE_PRODUCER_NAME).split(","));
	}

	public void pushMessageToKafka(String message) {
		for (String topicName : topicList) {
			final ProducerRecord<Long, String> record = new ProducerRecord<>(topicName, message);
			try {
				producer.send(record).get();
			} catch (Exception e) {
				// messageTrackerFile.writeMessage(fileName,fileName+ConstantUtils.ERROR_KAFKA_TRACK_CONSUME_MESSAGE
				// + bootstrapServer);
				final ProducerRecord<Long, String> errorRecord = new ProducerRecord<>(
						environment.getProperty(INSTANCE_ERROR_CONNECT_POINT_NAME), message);
				try {
					producer.send(errorRecord).get();
				} catch (InterruptedException | ExecutionException e1) {
					logger.error(e1);
				}
				logger.error(e);
			}
		}
	}

}
