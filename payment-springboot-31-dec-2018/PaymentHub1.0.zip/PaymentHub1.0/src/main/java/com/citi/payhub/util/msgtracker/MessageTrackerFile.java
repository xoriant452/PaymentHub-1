package com.citi.payhub.util.msgtracker;

import static com.citi.payhub.util.constant.ConstantUtils.MESSAGE_TRACKER_FILE_EXTENSION;
import static com.citi.payhub.util.constant.ConstantUtils.MESSAGE_TRACKER_FILE_PATH;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.citi.payhub.util.constant.ConstantUtils;

@Lazy
@Component
public class MessageTrackerFile {
	
	private  String filePath;
	
	private String fileExtension;
	
	@Autowired
	Environment environment;
	
	public MessageTrackerFile() {
		filePath=environment.getProperty(MESSAGE_TRACKER_FILE_PATH);
		fileExtension=environment.getProperty(MESSAGE_TRACKER_FILE_EXTENSION);
	}
	
	public void writeMessage(String fileName, String message) {
		File file = null;
		FileWriter fileWriter = null;
		try {
			file = new File(filePath + fileName + fileExtension);
			fileWriter = new FileWriter(file, true);
			boolean fvar = file.createNewFile();
			if (fvar) {
				fileWriter.write(message);
				fileWriter.close();
			} else {
				fileWriter.write(System.getProperty(ConstantUtils.LINE_SEPARATOR));
				fileWriter.write(message);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}finally {
			try {
				fileWriter.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	

	public void copyMessageLogToLogFile(String readFileName, String writeFileName) throws IOException, InterruptedException {
		File readFile = new File(filePath + readFileName + fileExtension);
		FileReader fileReader = new FileReader(readFile);
		BufferedReader bufferedReader = new BufferedReader(fileReader);
		FileWriter fileWriter = new FileWriter(filePath + writeFileName + fileExtension, true);
		String s;
		while ((s = bufferedReader.readLine()) != null) { 
			fileWriter.write(System.getProperty(ConstantUtils.LINE_SEPARATOR));
			fileWriter.write(s); 
			fileWriter.flush();
		}
		bufferedReader.close();
		fileWriter.close();
		//file will be deleted after successfully transform message
		//readFile.delete();
	}

}
