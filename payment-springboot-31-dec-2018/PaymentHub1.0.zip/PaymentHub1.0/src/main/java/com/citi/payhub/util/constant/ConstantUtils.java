package com.citi.payhub.util.constant;

public class ConstantUtils {

	public static final String KAFKA = "kafka";
	public static final String MQUEUE = "mqueue";
	public static final String RESTAPI = "restapi";
	public static final String FILE = "file";
	public static final String BLANKSTR = "";
	public static final String LINE_SEPARATOR = "line.separator";
	public static final String UTER = "UTER";
	public static final String TRACK_KAFKA_CONSUME_MESSAGE = "- Message consumed from kafka server ";
	public static final String ERROR_KAFKA_TRACK_CONSUME_MESSAGE = "- Error occures while consuming message from kafka server ";
	public static final String TRACK_KAFKA_PRODUCE_MESSAGE = "- Message produced on kafka server ";
	public static final String TRACK_MQ_CONSUME_MESSAGE = "- Message consumed from kafka server ";
	public static final String ERROR_MQ_TRACK_CONSUME_MESSAGE = "- Error occures while consuming message from kafka server ";
	public static final String TRACK_MQ_PRODUCE_MESSAGE = "- Message produced on kafka server ";
	public static final String TRACK_SEND_TRANSFORM_MESSAGE = "- Message has sent for transformation.";
	public static final String TRACK_SUCCESS_TRANSFORM_MESSAGE = "- Message has been transformed.";

	public static final String DESTINATION_MESSAGE = "DESTINATION_MESSAGE";
	public static final int MAX_CHAR = 5000;
	public static final String SOURCE_MESSAGE = "SOURCE_MESSAGE";
	public static final String MESSAGES = "messages";
	public static final String PUBLISHER = "pub";
	public static final String TRANSFORMER = "trans";
	public static final String SUBSCRIBER = "sub";

	// constant of application.properties file
	public static final String PAYHUB_APP_BEHAVE = "payhub.app.behave";
	
	public static final String INSTANCE_CONSUMER_CONFIG = "instance.consumer.config";
	public static final String INSTANCE_PRODUCE_CONFIG = "instance.produce.config";

	public static final String INSTANCE_CONSUMER_BOOTSTRAPSERVER = "instance.consumer.bootstrapServer";
	public static final String INSTANCE_CONSUMER_CONSUMERGROUP_ID = "instance.consumer.consumergroup.id";
	
	public static final String INSTANCE_PRODUCER_BOOTSTRAPSERVER = "instance.producer.bootstrapServer";
	public static final String INSTANCE_PRODUCER_CONSUMERGROUP_ID = "instance.producer.consumergroup.id";

	public static final String INSTANCE_CONSUMER_NAME = "instance.consumer_name";
	public static final String INSTANCE_PRODUCER_NAME = "instance.producer_name";
	public static final String INSTANCE_ERROR_CONNECT_POINT_NAME = "instance.error_connect_point_name";

	
	public static final String KAFKA_AUTOOFFSET = "kafka.autooffset";
	public static final String KAFKA_ISOLATION = "kafka.isolation";
	public static final String KAFKA_AUTOCOMMIT = "kafka.autocommit";
	public static final String KAFKA_FETCHMAXSIZE = "kafka.fetchmaxsize";
	public static final String KAFKA_IDEMPOTENCE = "kafka.idempotence";
	
	//kafka ssl config
	public static final String SECURITY_CONFIG_PROTOCOL="security.config.protocol";
	public static final String SSL_TRUSTSTORE_LOCATION_CONFIG_FILE_PATH="ssl.truststore.location.config.file.path";
	public static final String SSL_TRUSTSTORE_PASSWORD_CONFIG="ssl.truststore.password.config";
	
	public static final String TRANSFORM_JAR_PATH="transform.jar.path";
	public static final String TRANSFORM_CLASS_PATH="transform.class.path";
	public static final String TRANSFORM_METHOD_NAME="transform.method.name";
	
	
	public static final String MQ_CONSUME_QUEUENAME="spring.activemq.consume.queuename";
	public static final String MQ_PRODUCE_QUEUENAME="spring.activemq.produce.queuename";
	public static final String MQ_TRANSFORM_QUEUENAME="spring.activemq.transform.queuename";
	public static final String MQ_FINAL_QUEUENAME="spring.activemq.final.queuename";
	
	public static final String MESSAGE_TRACKER_FILE_PATH="message.tracker.file.path";
	public static final String MESSAGE_TRACKER_FILE_EXTENSION="message.tracker.file.extension";

}
