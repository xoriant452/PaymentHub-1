package com.citi.payhub.condition;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Conditional;
import org.springframework.context.annotation.Configuration;

import com.citi.payhub.sub.kafka.KafkaConsumer;

@Configuration
public class PaymentHubConditionConfig {
	
	@Autowired
	private KafkaConsumer consumerService;
	
	
	@Bean
	@Conditional(value = KafkaConfigCondition.class)
	public void kafkaConsumerModuleConfig(){
		consumerService.receiveKafkaMessage();
	}
	
/*	@Bean
	@Conditional(value = KafkaTransformCondition.class)
	public void kafkaTransformConfig(){
		logger.info("I am in receiveProducedMessagesForKafka");
		//kafkaTransformConsumerService.receiveProducedMessagesForKafka();
	}

	@Bean
	@Conditional(value = MessagingQueueConfigCondition.class)
	public void mQueueConfig() {
		logger.info("I am in MessagingQueueUtil");
	
	}

	@Bean
	@Conditional(value = MessagingQueueTransformCondition.class)
	public void mQueueTransformConfig() {
		logger.info("I am in MessagingQueueTransformCondition");
		//kafkaTransformConsumerService.receiveProducedMessagesForMQueue();
		
	}*/

}
