package com.citi.payhub.condition;

import org.springframework.context.annotation.Condition;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.core.type.AnnotatedTypeMetadata;

import com.citi.payhub.util.constant.ConstantUtils;

public class KafkaTransformCondition implements Condition {

	@Override
	public boolean matches(ConditionContext context, AnnotatedTypeMetadata metadata) {
		String config = context.getEnvironment().getProperty("payhub.transform.config");
		if (null != config && !ConstantUtils.BLANKSTR.equalsIgnoreCase(config)) {
			return config.equalsIgnoreCase(ConstantUtils.KAFKA);
		}
		return false;
	}
}
