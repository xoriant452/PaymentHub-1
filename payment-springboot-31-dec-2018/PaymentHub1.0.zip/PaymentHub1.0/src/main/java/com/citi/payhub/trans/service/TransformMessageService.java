package com.citi.payhub.trans.service;

import static com.citi.payhub.util.constant.ConstantUtils.*;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;

import javax.annotation.PostConstruct;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

@Lazy
@Component
public class TransformMessageService {

	private static Logger logger = LogManager.getLogger(TransformMessageService.class);

	private Class<?> beanClass = null;

	private Object beanObj = null;

	@Autowired
	private Environment environment;

	@PostConstruct
	private void getTransformMsgInstance() {
		try {
			URL[] classLoaderUrls = new URL[] { new URL("file:///" + environment.getProperty(TRANSFORM_JAR_PATH)) };
			URLClassLoader urlClassLoader = URLClassLoader.newInstance(classLoaderUrls,
					TransformMessageService.class.getClassLoader());
			beanClass = Class.forName(environment.getProperty(TRANSFORM_CLASS_PATH), true, urlClassLoader);
			Constructor<?> constructor = beanClass.getConstructor();
			beanObj = constructor.newInstance();
		} catch (Exception e) {
			logger.error(e);
		}
	}

	public String getTransferedMessage(String message) throws Exception {
		Method method = beanClass.getDeclaredMethod(environment.getProperty(TRANSFORM_METHOD_NAME), String.class);
		method.setAccessible(true);
		String str = (String) method.invoke(beanObj, message);
		System.out.println(str);
		return str;
	}

}
