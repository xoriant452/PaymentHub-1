package com.citi.payhub.trans.model;

public interface TransformMessageInterface {
	 public String getTransformedMessage(String message);
}
