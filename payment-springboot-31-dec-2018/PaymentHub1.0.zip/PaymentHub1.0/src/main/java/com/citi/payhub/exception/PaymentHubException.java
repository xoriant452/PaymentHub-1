package com.citi.payhub.exception;

import com.citi.payhub.model.MessageInfo;

public class PaymentHubException extends RuntimeException {

	private static final long serialVersionUID = -5564804276941086868L;

	private final String statusCode;
	private final String subStatusCode;

	public PaymentHubException() {
		super();
		statusCode = null;
		subStatusCode = null;
	}

	public PaymentHubException(MessageInfo messageInfo, String message) {
		super(message);
		statusCode = null;
		subStatusCode = null;
	}
	
	public PaymentHubException(String message) {
		super(message);
		statusCode = null;
		subStatusCode = null;
	}

	public PaymentHubException(MessageInfo messageInfo, String statusCode, String subStatusCode, String message) {
		super(message);
		this.statusCode = statusCode;
		this.subStatusCode = subStatusCode;
	}

	/**
	 * @param message
	 * @param cause
	 * @param enableSuppression
	 * @param writableStackTrace
	 */
	public PaymentHubException(MessageInfo messageInfo, String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		statusCode = null;
		subStatusCode = null;
	}

	public PaymentHubException(MessageInfo messageInfo, Exception exception) {
		super(exception);
		statusCode = null;
		subStatusCode = null;
	}

	public PaymentHubException(MessageInfo messageInfo, String message, Exception exception) {
		super(message, exception);
		statusCode = null;
		subStatusCode = null;
	}

	public PaymentHubException(MessageInfo messageInfo, Exception exception, String message) {
		super(message, exception);
		statusCode = null;
		subStatusCode = null;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public String getSubStatusCode() {
		return subStatusCode;
	}

	@Override
	public String toString() {
		return "[" + (statusCode != null ? "statusCode=" + statusCode + ", " : "")
				+ (subStatusCode != null ? "subStatusCode=" + subStatusCode + ", " : "")
				+ (getMessage() != null ? "Message=" + getMessage() : "") + "]";
	}
}
