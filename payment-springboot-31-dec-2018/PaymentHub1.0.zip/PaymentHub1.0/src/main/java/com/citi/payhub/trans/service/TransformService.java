package com.citi.payhub.trans.service;

import static com.citi.payhub.util.common.CommonUtils.getMessageMap;
import static com.citi.payhub.util.common.CommonUtils.setDestinationMessages;
import static com.citi.payhub.util.constant.ConstantUtils.BLANKSTR;
import static com.citi.payhub.util.constant.ConstantUtils.INSTANCE_PRODUCE_CONFIG;
import static com.citi.payhub.util.constant.ConstantUtils.KAFKA;
import static com.citi.payhub.util.constant.ConstantUtils.MQUEUE;
import static com.citi.payhub.util.constant.ConstantUtils.SOURCE_MESSAGE;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.citi.payhub.pub.kafka.KafkaProducer;
import com.citi.payhub.pub.mqueue.MqueueProducer;

@Service
@Lazy
public class TransformService {

	@Autowired
	private KafkaProducer kafkaProducer;

	@Autowired
	private TransformMessageService transformMessageService;

	@Autowired
	private Environment environment;

	@Autowired
	private MqueueProducer mqueueProducer;

	public void pushMsgToTransPublisher(String messageInfo) throws Exception {
		String publisherConfig = environment.getProperty(INSTANCE_PRODUCE_CONFIG);
		Map<String, Object> sourceMsg = getMessageMap(messageInfo);
		String transformedMsg = sendTransformMessageToKafka(sourceMsg.get(SOURCE_MESSAGE).toString());
		String transMessageInfo = setDestinationMessages(transformedMsg, messageInfo);
		System.out.println("Transformed Message===>" + transMessageInfo);
		if (null != publisherConfig && !BLANKSTR.equalsIgnoreCase(publisherConfig)
				&& KAFKA.equalsIgnoreCase(publisherConfig)) {
			kafkaProducer.pushMessageToKafka(transMessageInfo);
		} else if (null != publisherConfig && !BLANKSTR.equalsIgnoreCase(publisherConfig)
				&& MQUEUE.equalsIgnoreCase(publisherConfig)) {
			mqueueProducer.publishMessageToQueue(transMessageInfo);
		}
	}

	private String sendTransformMessageToKafka(String message) throws Exception {
		return transformMessageService.getTransferedMessage(message);
	}

}
