package com.citi.payhub.pub.mqueue;

import static com.citi.payhub.util.constant.ConstantUtils.MQ_PRODUCE_QUEUENAME;

import java.util.Arrays;
import java.util.List;

import javax.jms.Queue;

import org.apache.activemq.command.ActiveMQQueue;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.core.env.Environment;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;

/**
 * 
 * @author Yogesh Mohite
 * @CreationDate 20/12/2018
 * @version 1.0
 */
@Lazy
@Component
public class MqueueProducer {

	
	@Autowired
	private JmsTemplate jmsTemplate;
	
	@Autowired
	private Environment environment;
	

	private Queue getQueue(String queue) {
		return new ActiveMQQueue(queue);
	}

	public void publishMessageToQueue(String message) {
		List<String> queueList = Arrays.asList(environment.getProperty(MQ_PRODUCE_QUEUENAME).split(","));
		for (String queueName : queueList) {
		jmsTemplate.convertAndSend(getQueue(queueName),message);
		}
	}
	
}
