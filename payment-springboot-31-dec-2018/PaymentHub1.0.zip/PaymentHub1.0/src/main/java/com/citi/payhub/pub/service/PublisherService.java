package com.citi.payhub.pub.service;

import static com.citi.payhub.util.constant.ConstantUtils.BLANKSTR;
import static com.citi.payhub.util.constant.ConstantUtils.INSTANCE_PRODUCE_CONFIG;
import static com.citi.payhub.util.constant.ConstantUtils.KAFKA;
import static com.citi.payhub.util.constant.ConstantUtils.MQUEUE;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.citi.payhub.model.MessageInfo;
import com.citi.payhub.pub.kafka.KafkaProducer;
import com.citi.payhub.pub.mqueue.MqueueProducer;
import com.google.gson.Gson;

/**
 * 
 * @author Yogesh Mohite
 * @CreationDate 20/12/2018
 * @version 1.0
 */

@Lazy
@Service
public class PublisherService {

	@Autowired
	private KafkaProducer producerService;

	@Autowired
	Environment environment;

	@Autowired
	private MqueueProducer mqueueProducer;
	
	private Gson gson = new Gson();
	

	public void pushMsgToInternalPublisher(String message) throws Exception {
		String publisherConfig = environment.getProperty(INSTANCE_PRODUCE_CONFIG);
		String msgInfo = gson.toJson(new MessageInfo(message));
		if (null != publisherConfig && !BLANKSTR.equalsIgnoreCase(publisherConfig)
				&& KAFKA.equalsIgnoreCase(publisherConfig)) {
			producerService.pushMessageToKafka(msgInfo);
		} else if (null != publisherConfig && !BLANKSTR.equalsIgnoreCase(publisherConfig)
				&& MQUEUE.equalsIgnoreCase(publisherConfig)) {
			mqueueProducer.publishMessageToQueue(msgInfo);
		}
	}
}
