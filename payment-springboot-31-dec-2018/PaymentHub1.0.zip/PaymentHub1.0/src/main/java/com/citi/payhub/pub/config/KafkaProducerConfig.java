package com.citi.payhub.pub.config;

import static com.citi.payhub.util.constant.ConstantUtils.*;

import java.util.HashMap;
import java.util.Map;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.LongSerializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

/**
 * 
 * @author Yogesh Mohite
 * @CreationDate 20/12/2018
 * @version 1.0
 */
@Lazy
@Component
public class KafkaProducerConfig {

	@Autowired
	Environment environment;

	public Map<String, Object> getProducerProperties() {
		Map<String, Object> configProps = new HashMap<>();
		configProps.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, LongSerializer.class);
		configProps.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
		configProps.put(ProducerConfig.MAX_REQUEST_SIZE_CONFIG, 2147483647);
		configProps.put(ProducerConfig.RECONNECT_BACKOFF_MAX_MS_CONFIG, 5000);
		configProps.put(ProducerConfig.RECONNECT_BACKOFF_MS_CONFIG, 50);
		configProps.put(ProducerConfig.ACKS_CONFIG, "all");
		// configure the following three settings for SSL Encryption

		/*
		 * configProps.put(SslConfigs.SSL_ENDPOINT_IDENTIFICATION_ALGORITHM_CONFIG,
		 * BLANKSTR); configProps.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG,
		 * environment.getProperty(SECURITY_CONFIG_PROTOCOL));
		 * configProps.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG,
		 * environment.getProperty(SSL_TRUSTSTORE_LOCATION_CONFIG_FILE_PATH));
		 * configProps.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG,
		 * environment.getProperty(SSL_TRUSTSTORE_PASSWORD_CONFIG));
		 */

		return configProps;
	}

	/**
	 * This method creates the Producer instance.
	 * 
	 * @return KafkaProducer<Long, String>
	 */
	public Producer<Long, String> getProducer(String bootstrapServer) {
		Map<String, Object> props = getProducerProperties();
		props.put(ProducerConfig.CLIENT_ID_CONFIG, environment.getProperty(INSTANCE_PRODUCER_CONSUMERGROUP_ID));
		props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServer);
		return new KafkaProducer<>(props);
	}

}
