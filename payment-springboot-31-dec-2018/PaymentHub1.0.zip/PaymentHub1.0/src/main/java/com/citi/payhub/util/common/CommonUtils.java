package com.citi.payhub.util.common;

import java.util.Map;

import com.citi.payhub.model.MessageInfo;
import static com.citi.payhub.util.constant.ConstantUtils.DESTINATION_MESSAGE;
import com.google.gson.Gson;

public class CommonUtils {

	private static Gson gson = new Gson();
	
	public static Map<String,Object> getMessageMap(String message) {
		MessageInfo messageInfo = gson.fromJson(message, MessageInfo.class);
		return (Map<String,Object>) messageInfo.getMessages();
	}

	public static String setDestinationMessages(String message,String messageInfo) {
		MessageInfo msgInfoObj = gson.fromJson(messageInfo, MessageInfo.class);
		msgInfoObj.getMessages().put(DESTINATION_MESSAGE, message);
		return gson.toJson(msgInfoObj);
	}
	
}
