package com.citi.payhub.sub.kafka;

import static com.citi.payhub.util.constant.ConstantUtils.BLANKSTR;
import static com.citi.payhub.util.constant.ConstantUtils.INSTANCE_CONSUMER_BOOTSTRAPSERVER;
import static com.citi.payhub.util.constant.ConstantUtils.INSTANCE_CONSUMER_CONSUMERGROUP_ID;
import static com.citi.payhub.util.constant.ConstantUtils.INSTANCE_CONSUMER_NAME;
import static com.citi.payhub.util.constant.ConstantUtils.PAYHUB_APP_BEHAVE;
import static com.citi.payhub.util.constant.ConstantUtils.PUBLISHER;
import static com.citi.payhub.util.constant.ConstantUtils.SUBSCRIBER;
import static com.citi.payhub.util.constant.ConstantUtils.TRANSFORMER;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;

import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.citi.payhub.pub.service.PublisherService;
import com.citi.payhub.sub.config.KafkaConsumerConfig;
import com.citi.payhub.sub.service.SubscriberService;
import com.citi.payhub.trans.service.TransformService;

/**
 * 
 * @author Yogesh Mohite
 * @CreationDate 20/12/2018
 * @version 1.0
 */
@Lazy
@Component
public class KafkaConsumer {

	private static Logger logger = LogManager.getLogger(KafkaConsumer.class);

	@Autowired
	private KafkaConsumerConfig kafkaConsumerConfig;

	@Autowired
	private Environment environment;

	@Autowired
	private SubscriberService subscriberService;
	@Autowired
	private TransformService transformService;
	@Autowired
	private PublisherService publisherService;

	public void receiveKafkaMessage() {
		String appBehave = environment.getProperty(PAYHUB_APP_BEHAVE);
		try {
			List<String> topicList = Arrays.asList(environment.getProperty(INSTANCE_CONSUMER_NAME).split(","));
			Consumer<Long, String> consumer = kafkaConsumerConfig.createConsumer(topicList,
					environment.getProperty(INSTANCE_CONSUMER_BOOTSTRAPSERVER),
					environment.getProperty(INSTANCE_CONSUMER_CONSUMERGROUP_ID));
			while (true) {
				ConsumerRecords<Long, String> records = null;
				try {
					records = consumer.poll(Duration.ofMillis(100));
				} catch (Exception e) {
					logger.error(e);
				}
				consumer.commitSync();
				if (null != records && !records.isEmpty()) {
					for (ConsumerRecord<Long, String> record : records) {
						String message = record.value();
						logger.info("Consumed Message=" + message);
						if (null != appBehave && !BLANKSTR.equalsIgnoreCase(appBehave)
								&& PUBLISHER.equalsIgnoreCase(appBehave)) {
							publisherService.pushMsgToInternalPublisher(message);
						} else if (null != appBehave && !BLANKSTR.equalsIgnoreCase(appBehave)
								&& TRANSFORMER.equalsIgnoreCase(appBehave)) {
							transformService.pushMsgToTransPublisher(message);
						} else if (null != appBehave && !BLANKSTR.equalsIgnoreCase(appBehave)
								&& SUBSCRIBER.equalsIgnoreCase(appBehave)) {
							subscriberService.pushMsgToExternalPublisher(message);
						}
					}
				}
			}
		} catch (Exception e) {
			logger.error(e);
		}
	}

}
