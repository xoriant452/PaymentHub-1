package com.citi.payhub.service;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutionException;

import javax.annotation.PostConstruct;

import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.citi.payhub.configuration.KafkaProducerConfig;
import com.citi.payhub.util.CommonUtils;
import com.citi.payhub.util.ConstantUtils;
import com.citi.payhub.util.MessageTrackerFile;

/**
 * Producer Service
 * 
 * @author Yogesh Mohite
 * @CreationDate 26/10/2018
 * @version 1.0
 */
@Component
public class KafkaProducerModuleService {

	private Logger logger = LogManager.getLogger(KafkaProducerModuleService.class);

	@Value("${spring.kafka.produce.bootstrapServer}")
	private String bootstrapServer;

	@Value("${spring.kafka.final.topic1}")
	private String finalTopic1;

	@Value("${spring.kafka.final.topic2}")
	private String finalTopic2;

	@Value("${spring.kafka.pub.trans.msg.topics}")
	private String pubTransTopicList;
	
	@Value("${spring.kafka.error.topic}")
	private String errorTopic;

	@Autowired
	private KafkaProducerConfig kafkaProducerConfig;

	@Autowired
	private TransformMessageService transformMessageService;
	
	@Autowired
	MessageTrackerFile messageTrackerFile;

	private Producer<Long, String> producer;

	@PostConstruct
	public void initProducer() {
		producer = kafkaProducerConfig.getTransactionalProducer(bootstrapServer);
		//producer.initTransactions();
	}

	/**
	 * Method reprocess the error message which is come from Error message topic.
	 * 
	 * @param topic
	 * @param errorMessage
	 */
	public void pushMessageToKafka(String message, String topic, long offset, String groupId) {
		try {
			/*Map<TopicPartition, OffsetAndMetadata> groupCommit = new HashMap<TopicPartition, OffsetAndMetadata>();
			groupCommit.put(new TopicPartition(topic, 0), new OffsetAndMetadata(offset + 1, null));*/
			//producer.beginTransaction();
			sendTransformMessageToKafka(message);
			/*producer.sendOffsetsToTransaction(groupCommit, groupId);
			producer.commitTransaction();*/
		} catch (Exception e) {
			final ProducerRecord<Long, String> errorRecord = new ProducerRecord<>(errorTopic, message);
			try {
				producer.send(errorRecord).get();
			} catch (InterruptedException | ExecutionException e1) {
				e1.printStackTrace();
			}
			logger.error(e);
		} finally {

		}
	}

	private void sendTransformMessageToKafka(String message) throws InterruptedException, ExecutionException {
		List<String> topicList = Arrays.asList(pubTransTopicList.split(","));
		String fileName=CommonUtils.getUTER(message);
		messageTrackerFile.writeMessage(fileName,fileName+ConstantUtils.TRACK_SEND_TRANSFORM_MESSAGE);
		String transformedMessage = transformMessageService.sendTransformMessageFirst(message);
		messageTrackerFile.writeMessage(fileName,fileName+ConstantUtils.TRACK_SUCCESS_TRANSFORM_MESSAGE);
		for (int i = 0; i < topicList.size(); i++) {
			final ProducerRecord<Long, String> record = new ProducerRecord<>(topicList.get(i), transformedMessage);
			try {
				messageTrackerFile.writeMessage(fileName,fileName+ConstantUtils.TRACK_KAFKA_PRODUCE_MESSAGE+bootstrapServer);
				producer.send(record).get();
			}catch(Exception e) {
				logger.error(e);
			}finally {
				try {
					messageTrackerFile.copyMessageLogToLogFile(fileName, "MessageTracker");
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

}
