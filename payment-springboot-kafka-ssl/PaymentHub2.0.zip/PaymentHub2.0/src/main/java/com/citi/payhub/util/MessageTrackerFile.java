package com.citi.payhub.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

@Component
@Configuration
public class MessageTrackerFile {
	
	@Value("${spring.message.tracker.file.path}")
	private  String filePath;
	
	@Value("${spring.message.tracker.file.extension}")
	private String fileExtension;
	
	public void writeMessage(String fileName, String message) {
		File file = null;
		FileWriter fileWriter = null;
		try {
			file = new File(filePath + fileName + fileExtension);
			fileWriter = new FileWriter(file, true);
			boolean fvar = file.createNewFile();
			if (fvar) {
				fileWriter.write(message);
				fileWriter.close();
			} else {
				fileWriter.write(System.getProperty(ConstantUtils.LINE_SEPARATOR));
				fileWriter.write(message);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}finally {
			try {
				fileWriter.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	

	public void copyMessageLogToLogFile(String readFileName, String writeFileName) throws IOException, InterruptedException {
		File readFile = new File(filePath + readFileName + fileExtension);
		FileReader fileReader = new FileReader(readFile);
		BufferedReader bufferedReader = new BufferedReader(fileReader);
		FileWriter fileWriter = new FileWriter(filePath + writeFileName + fileExtension, true);
		String s;
		while ((s = bufferedReader.readLine()) != null) { 
			fileWriter.write(System.getProperty(ConstantUtils.LINE_SEPARATOR));
			fileWriter.write(s); 
			fileWriter.flush();
		}
		bufferedReader.close();
		fileWriter.close();
		//file will be deleted after successfully transform message
		//readFile.delete();
	}

}
