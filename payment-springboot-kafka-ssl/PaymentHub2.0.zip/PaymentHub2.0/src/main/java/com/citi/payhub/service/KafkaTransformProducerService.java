package com.citi.payhub.service;

import java.util.concurrent.ExecutionException;

import javax.annotation.PostConstruct;

import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.citi.payhub.configuration.KafkaProducerConfig;
import com.citi.payhub.util.CommonUtils;
import com.citi.payhub.util.ConstantUtils;
import com.citi.payhub.util.MessageTrackerFile;


/**
 * Producer Service
 * 
 * @author Yogesh Mohite
 * @CreationDate 26/11/2018
 * @version 1.0
 */
@Component
public class KafkaTransformProducerService {

	private Logger logger = LogManager.getLogger(KafkaTransformProducerService.class);
	
	@Value("${spring.kafka.transform.produce.bootstrapServer}")
	private String bootstrapServer;

	@Value("${spring.kafka.error.topic}")
	private String errorTopic;
	
	@Autowired
	private KafkaProducerConfig kafkaProducerConfig;
	
	@Autowired
	MessageTrackerFile messageTrackerFile;
	
	private Producer<Long, String> producer;
	
	@PostConstruct
	public void initProducer() {
		producer = kafkaProducerConfig.getProducer(bootstrapServer);
		//producer.initTransactions();
	}
	

	/**
	 * Method reprocess the error message which is come from Error message topic.
	 * @param topic
	 * @param errorMessage
	 */
	public void pushMessageToKafka(String topic, String message,String groupId) {
		//producer.beginTransaction();
		final ProducerRecord<Long, String> record = new ProducerRecord<>(topic, message);
		String fileName=CommonUtils.getUTER(message);
		try {
			producer.send(record).get();
			//producer.commitTransaction();
			messageTrackerFile.writeMessage(fileName,fileName+ConstantUtils.TRACK_KAFKA_CONSUME_MESSAGE + bootstrapServer);
		} catch (Exception e) {
			messageTrackerFile.writeMessage(fileName,fileName+ConstantUtils.ERROR_KAFKA_TRACK_CONSUME_MESSAGE + bootstrapServer);
			final ProducerRecord<Long, String> errorRecord = new ProducerRecord<>(errorTopic, message);
			try {
				producer.send(errorRecord).get();
			} catch (InterruptedException | ExecutionException e1) {
				e1.printStackTrace();
			}
			logger.error(e);
		}
	}

}
