package com.citi.payhub.service;

import java.time.Duration;

import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

import com.citi.payhub.configuration.KafkaConsumerConfig;
import com.citi.payhub.util.CommonUtils;
import com.citi.payhub.util.ConstantUtils;
import com.citi.payhub.util.MessageTrackerFile;

/**
 * Kafka Consumer Module Service
 * 
 * @author Yogesh Mohite
 * @CreationDate 26/11/2018
 * @version 1.0
 */
@Lazy
@Component
public class KafkaConsumerModuleService {
	
	private static Logger logger = LogManager.getLogger(KafkaConsumerModuleService.class);

	@Autowired
	private KafkaConsumerConfig kafkaConsumerConfig;

	@Value("${spring.kafka.consume.bootstrapServer}")
	private String bootstrapServer;

	@Value("${spring.kafka.consume.topic}")
	private String topic;

	@Value("${spring.kafka.consumergroup.id1}")
	private String groupId;

	@Value("${spring.kafka.produce.topic}")
	private String producerTopic;

	@Autowired
	private KafkaTransformProducerService kafkaProducerService;
	
	@Autowired
	MessageTrackerFile messageTrackerFile;

	public void receiveMessage() {
		new Thread(() -> {
			Consumer<Long, String> consumer = kafkaConsumerConfig.createConsumer(topic, bootstrapServer, groupId);
			int cnt=0;
		while (true) {
			ConsumerRecords<Long, String> records=null;
			try {
			 records = consumer.poll(Duration.ofMillis(100));
			}catch(Exception e) {
				logger.error(e);
			}
			 consumer.commitSync();
			if(null!=records && !records.isEmpty()) {
			for (ConsumerRecord<Long, String> record : records) {
				logger.info(++cnt+"   Message="+record.value());
				String fileName=CommonUtils.getUTER(record.value());
				messageTrackerFile.writeMessage(fileName,fileName+ConstantUtils.TRACK_KAFKA_CONSUME_MESSAGE);
				kafkaProducerService.pushMessageToKafka(producerTopic, record.value(), groupId);
			}
			}
		}
		}).start();
	}

}
