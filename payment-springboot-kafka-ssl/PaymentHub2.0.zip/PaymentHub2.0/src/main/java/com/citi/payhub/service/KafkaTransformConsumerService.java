package com.citi.payhub.service;

import java.time.Duration;

import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

import com.citi.payhub.configuration.KafkaConsumerConfig;
import com.citi.payhub.util.CommonUtils;
import com.citi.payhub.util.ConstantUtils;
import com.citi.payhub.util.MessageTrackerFile;

@Lazy
@Component
public class KafkaTransformConsumerService {
	private static Logger logger = LogManager.getLogger(KafkaTransformConsumerService.class);
	
	@Autowired
	private KafkaConsumerConfig kafkaConsumerConfig;
	
	@Value("${spring.kafka.transform.consume.bootstrapServer}")
	private String bootstrapServer;
	
	@Value("${spring.kafka.produce.topic}")
	private String topic;
	
	@Value("${spring.kafka.consumergroup.id2}")
	private String groupId;
	
	 
	@Autowired
	private KafkaProducerModuleService kafkaProducerModuleService;
	
	@Autowired
	private MQueueProducerService mQueueProducerService;
	
	@Autowired
	MessageTrackerFile messageTrackerFile;
	
	public void receiveProducedMessagesForKafka() {
		
		new Thread(() -> {
			Consumer<Long,String> consumer=kafkaConsumerConfig.createConsumer(topic,bootstrapServer,groupId);
		while(true) {
			ConsumerRecords<Long,String> records=null ;
			try {
				 records = consumer.poll(Duration.ofMillis(100));
				 consumer.commitSync();
				}catch(Exception e) {
					logger.error(e);
				}
			if(null!=records && !records.isEmpty()) {
            for (ConsumerRecord<Long,String> record : records) {
            	logger.info("");
                //logger.info("Received Message topic ={}, partition ={}, offset = {}, key = {}, value = {}\n", record.topic(), record.partition(), record.offset(), record.key(), record.value());
                String message=record.value();
                String fileName=CommonUtils.getUTER(message);
                messageTrackerFile.writeMessage(fileName,fileName+ConstantUtils.TRACK_KAFKA_CONSUME_MESSAGE + bootstrapServer);
            	kafkaProducerModuleService.pushMessageToKafka(message,topic,record.offset(),groupId);
               }
			}
		}}).start();
      }
	
	public void receiveProducedMessagesForMQueue() {
		new Thread(() -> {
			Consumer<Long,String> consumer=kafkaConsumerConfig.createConsumer(topic,bootstrapServer,groupId);
		consumer.commitSync();
		while(true) {
		ConsumerRecords<Long,String> records = consumer.poll(Duration.ofMillis(100));
            for (ConsumerRecord<Long,String> record : records) {
                //logger.info("Received Message topic ={}, partition ={}, offset = {}, key = {}, value = {}\n", record.topic(), record.partition(), record.offset(), record.key(), record.value());
                String message=record.value();
                mQueueProducerService.publishMessageToQueue(message);
               }
		}
	}).start();
      }

	
}
