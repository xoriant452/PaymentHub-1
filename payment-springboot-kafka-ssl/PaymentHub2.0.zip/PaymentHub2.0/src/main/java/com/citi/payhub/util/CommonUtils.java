package com.citi.payhub.util;

import org.json.JSONObject;

public class CommonUtils {

	/**
	 * This method parse the JSON string and fetch the UTER.
	 * 
	 * @param message
	 * @return UTER
	 */
	public static String getUTER(String message) {
		JSONObject jObject = new JSONObject(message);
		return (String) jObject.get(ConstantUtils.UTER);
	}
	
}
