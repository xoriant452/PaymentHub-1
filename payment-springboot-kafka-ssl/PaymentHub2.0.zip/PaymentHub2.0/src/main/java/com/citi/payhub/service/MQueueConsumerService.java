package com.citi.payhub.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

import com.citi.payhub.util.CommonUtils;
import com.citi.payhub.util.ConstantUtils;
import com.citi.payhub.util.MessageTrackerFile;

@Component
public class MQueueConsumerService {

	@Autowired
	private KafkaTransformProducerService kafkaProducerService;

	@Value("${spring.kafka.consume.bootstrapServer}")
	private String bootstrapServer;

	@Value("${spring.kafka.consume.topic}")
	private String topic;

	@Value("${spring.kafka.consumergroup.id1}")
	private String groupId;

	@Value("${spring.kafka.produce.topic}")
	private String producerTopic;
	
	@Autowired
	MessageTrackerFile messageTrackerFile;

	@JmsListener(destination = "${spring.activemq.queueName}",containerFactory = "myFactory")
	public void receiveQueue(String message) {
		System.out.println(message);
		String fileName=CommonUtils.getUTER(message);
		messageTrackerFile.writeMessage(fileName,fileName+ConstantUtils.TRACK_MQ_CONSUME_MESSAGE);
		kafkaProducerService.pushMessageToKafka(producerTopic, message, groupId);
	}

}
