package com.citi.payhub.model;

public interface TransformMessage {
	public String getTransformedMessage(String message);
}
