package com.citi.app.msg.exception;

import javax.jms.ExceptionListener;
import javax.jms.JMSException;

/**
 * @author clouduser
 *
 */
public class JmsExceptionListener implements ExceptionListener{

	@Override
	public void onException(JMSException exception) {
		// TODO Auto-generated method stub
		
	}

}
