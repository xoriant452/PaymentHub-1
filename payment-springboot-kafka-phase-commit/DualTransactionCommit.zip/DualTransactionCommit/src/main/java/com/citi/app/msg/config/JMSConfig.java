package com.citi.app.msg.config;

import java.util.HashMap;
import java.util.Map;

import javax.jms.ExceptionListener;
import javax.jms.Queue;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.command.ActiveMQQueue;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jms.connection.CachingConnectionFactory;
import org.springframework.jms.connection.JmsTransactionManager;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.support.AbstractPlatformTransactionManager;

import com.citi.app.msg.exception.JmsExceptionListener;

@Configuration
@EnableTransactionManagement
@EnableKafka
public class JMSConfig {

	@Value("${spring.activemq.broker-url}")
	private String brokerUrl;

	@Value("${spring.activemq.senderQueue}")
	private String senderQueue;

	/*
	 * @Value("${spring.activemq.queueName}") private String queue;
	 */

	@Value("${spring.activemq.user}")
	private String userString;

	@Value("${spring.activemq.password}")
	private String passString;

	@Value("${jms.sessionCacheSize}")
	private int sessionCacheSize;

	@Value("${spring.bootstrapServer}")
	private String bootstrapServer;

	@Value("${spring.transactionId}")
	private String txnId;

	@Bean
	public Queue queue() {
		return new ActiveMQQueue(senderQueue);
	}

	private ExceptionListener jmsExceptionListener() {
		return new JmsExceptionListener();
	}

	public CachingConnectionFactory activeMQConnectionFactory() {
		System.out.println("Creating cached connection factory");
		ActiveMQConnectionFactory activeMQConnectionFactory = new ActiveMQConnectionFactory(userString, passString,
				brokerUrl);
		CachingConnectionFactory cachingConnectionFactory = new CachingConnectionFactory(activeMQConnectionFactory);
		cachingConnectionFactory.setExceptionListener(jmsExceptionListener());
		cachingConnectionFactory.setSessionCacheSize(sessionCacheSize);
		return cachingConnectionFactory;
	}

	@Bean
	public JmsTransactionManager jmsTransactionManager() {
		System.out.println("Initializing JMS Transaction");
		JmsTransactionManager jtm = new JmsTransactionManager(activeMQConnectionFactory());
		jtm.setTransactionSynchronization(AbstractPlatformTransactionManager.SYNCHRONIZATION_ON_ACTUAL_TRANSACTION);
		return jtm;
	}

	public Map<String, Object> producerConfigs() {
		Map<String, Object> props = new HashMap<>();
		props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServer);
		props.put(ProducerConfig.TRANSACTIONAL_ID_CONFIG, txnId);
		props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
		props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
		return props;
	}

	public ProducerFactory<String, String> producerFactory() {
		DefaultKafkaProducerFactory<String, String> prodFactory = new DefaultKafkaProducerFactory<>(producerConfigs());
		prodFactory.setTransactionIdPrefix("txn-ingestor");
		return prodFactory;
	}

	@Bean
	public JmsTemplate jmsTemplate() {
		JmsTemplate jms = new JmsTemplate();
		jms.setConnectionFactory(activeMQConnectionFactory());
		jms.setSessionTransacted(true);
		return jms;
	}

}
