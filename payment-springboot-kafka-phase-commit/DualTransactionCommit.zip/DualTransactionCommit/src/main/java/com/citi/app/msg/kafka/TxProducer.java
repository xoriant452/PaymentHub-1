package com.citi.app.msg.kafka;

import java.util.Properties;

import javax.annotation.PostConstruct;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.KafkaException;
import org.apache.kafka.common.serialization.StringSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
class TxProducer {
	
	@Value("${spring.topicName.producer}")
	String topic;
	
	@Value("${spring.bootstrapServer}")
	String bootstrapServer;
	
	@Value("${spring.clientId}")
	String clientId;
	
	@Value("${spring.transactionId}")
	String transactionId;
	
	/*@Autowired
	KafkaTemplate kafkaTemplate;*/

	int noOfMessages = 1;
	private Producer<String, String> producer;
	//long delay = 1_000;
	static int number = 0;
	private static final Logger logger = LoggerFactory.getLogger(TxProducer.class);

	/**
	 * This method will send the message every 3 seconds
	 */
	void sendMessage(String message) {
		try {
				//producer.beginTransaction(); // begin transactions
				logger.info("Sending msg from TxProducer: " + number);
				producer.send(new ProducerRecord<String, String>(topic, "" + number, message));
				//kafkaTemplate.send(topic, message);
				number++;
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
				}
				//producer.commitTransaction(); // commit

		} catch (KafkaException e) {
			// For all other exceptions, just abort the transaction and try again.
			//producer.abortTransaction();
		}
	}

	/**
	 * @return Producer<String, String>
	 * This method will create idempotent producer instance
	 */
	/*@PostConstruct
	void createProducer() {
		Properties producerConfig = new Properties();
		producerConfig.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServer);
		producerConfig.put(ProducerConfig.CLIENT_ID_CONFIG, clientId);
		producerConfig.put(ProducerConfig.ENABLE_IDEMPOTENCE_CONFIG, true); // enable idempotence
		producerConfig.put(ProducerConfig.TRANSACTIONAL_ID_CONFIG, transactionId); // set transaction id
		producerConfig.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
		producerConfig.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
		producer = new KafkaProducer<>(producerConfig);
		//producer.initTransactions();
	}*/

}
