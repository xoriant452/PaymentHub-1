package com.citi.app.msg;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

import com.citi.app.msg.kafka.TxConsumer;

@SpringBootApplication
@ComponentScan(basePackages="com.citi.app.msg.*")
public class DualTransactionCommitApplication implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(DualTransactionCommitApplication.class, args);
	}
	
	@Autowired
	TxConsumer txConsumer;

	@Override
	public void run(String... args) throws Exception {
		txConsumer.receiveMessage();
	}
}
