package com.citi.app.msg.kafka;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.consumer.OffsetAndMetadata;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.KafkaException;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.citi.app.msg.mq.MessageService;

@Component
@EnableTransactionManagement
public class TxConsumer {

	@Value("${spring.topicName}")
	String topic;
	
	@Value("${spring.topicName.producer}")
	String producerTopic;

	@Value("${spring.bootstrapServer}")
	String bootstrapServer;

	@Value("${spring.consumergroup.id1}")
	String groupId;

	@Value("${spring.isolation}")
	String isolationLevel;

	@Value("${spring.autooffset}")
	String autoOffsetReset;

	@Value("${spring.clientId}")
	String clientId;

	@Value("${spring.transactionId}")
	String transactionId;

	@Autowired
	MessageService service;

	int kafkaSuccess = 0;
	int mqSuccess = 0;

	KafkaConsumer<String, String> consumer;

	int noOfMessages = 1;
	static int number = 0;
	private Producer<String, String> producer;

	private static final Logger logger = LoggerFactory.getLogger(TxConsumer.class);

    private Consumer createConsumer() {
        Properties consumerConfig = new Properties();
        consumerConfig.put("group.id", "exactly-once-group");
        consumerConfig.put("bootstrap.servers", bootstrapServer);
        consumerConfig.put("auto.offset.reset", "earliest");
        consumerConfig.put(ConsumerConfig.ISOLATION_LEVEL_CONFIG, "read_committed");
        consumerConfig.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "false");
        consumerConfig.put("max.poll.records", "1");
        consumerConfig.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        consumerConfig.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);

        Consumer consumer = new KafkaConsumer<Integer, String>(consumerConfig);
        consumer.subscribe(Arrays.asList(topic));

        return consumer;
    }

    private Producer createProducer() {
        Map<String, Object> configProps = new HashMap<String, Object>();
        configProps.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServer);
        configProps.put(ProducerConfig.TRANSACTIONAL_ID_CONFIG,"my-transactional-id1");
        configProps.put(ProducerConfig.CLIENT_ID_CONFIG, "transactional-producer");
        configProps.put(ProducerConfig.ENABLE_IDEMPOTENCE_CONFIG,"True");
        configProps.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        configProps.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);

        Producer producer = new KafkaProducer<Integer, String>(configProps);
        producer.initTransactions();

        return producer;
    }
    
    public void receiveMessage() {
    	KafkaConsumer<Integer, String> consumer = (KafkaConsumer<Integer, String>) createConsumer();
        KafkaProducer<Integer, String> producer = (KafkaProducer<Integer, String>) createProducer();

        while (true) {
            try {

                producer.beginTransaction();

                ConsumerRecords<Integer, String> records = consumer.poll(100);
                Map<TopicPartition, OffsetAndMetadata> groupCommit = new HashMap<TopicPartition, OffsetAndMetadata>();
                for (ConsumerRecord<Integer, String> record : records) {

                    System.out.printf("Received Message topic=%s, partition = %d, offset = %d, key = %s, value = %s\n",
                            record.topic(), record.partition(), record.offset(), record.key(), record.value());

                    groupCommit.put(new TopicPartition(topic, 0), new OffsetAndMetadata(record.offset() + 1, null));

                }
                if (!groupCommit.isEmpty()) {
                    producer.sendOffsetsToTransaction(groupCommit, "exactly-once-group");
                    
                    OffsetAndMetadata offsetAndMetadata = groupCommit.get(new TopicPartition(topic, 0));
                    if (offsetAndMetadata != null) {
                        System.out.printf("Commtting offset: %d for Topic partion: %d\n",
                                offsetAndMetadata.offset(), 0);
                    }
                }
                producer.commitTransaction();
                //Process MQ Msg
                for(ConsumerRecord<Integer, String> record : records) {
                	processMQ(record.value());
                }

            } catch (Exception exc) {
                producer.abortTransaction();
                exc.printStackTrace();
            } finally {
                // do nothing
            }
            try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }
    }



	private String processMQ(String value) {
		String status;
		try {
			service.publish(value);
			status = "success";
		} catch (Exception e) {
			e.printStackTrace();
			status = "failure";
		}

		return status;

	}
	@Deprecated
	private String processKafka(final String value) {
		String status = null;
		try {
			logger.info("Sending msg from TxProducer: " + number);
			producer.send(new ProducerRecord<String, String>(producerTopic, "" + number, value));
			// kafkaTemplate.send(topic, message);
			number++;
			status = "success";
			Thread.sleep(1000);
		} catch (KafkaException ke) {
			producer.abortTransaction();
			status = "failure";
		} catch (Exception e) {
			e.printStackTrace();
			status = "failure";
		}
		return status;
	}


}