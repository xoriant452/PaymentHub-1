package com.citi.payhub.pub.config;

import java.util.HashMap;
import java.util.Map;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.LongSerializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

/**
 * Kafka Producer Config
 * 
 * @author Yogesh Mohite
 * @CreationDate 26/11/2018
 * @version 1.0
 */
@Lazy
@Component
public class KafkaProducerConfig {

	@Value("${spring.kafka.isolation}")
	private String isolationLevel;

	@Value("${spring.kafka.autooffset}")
	private String autoOffsetReset;

	@Value("${spring.kafka.autocommit}")
	private String autoCommit;

	@Value("${spring.kafka.producer.clientId}")
	private String producerClientId;

	@Value("${spring.kafka.idempotence}")
	private String idempotence;
	
	@Value("${security.config.protocol}")
	private String secureProtocol;

	@Value("${ssl.truststore.location.config.file.path}")
	private String trustStoreConfigFilePath;
	
	@Value("${ssl.truststore.password.config}")
	private String trustStorePassword;
	
	public Map<String, Object> getProducerProperties() {
		Map<String, Object> configProps = new HashMap<>();
		configProps.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, LongSerializer.class);
		configProps.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
		configProps.put(ProducerConfig.MAX_REQUEST_SIZE_CONFIG, 2147483647);
		configProps.put(ProducerConfig.RECONNECT_BACKOFF_MAX_MS_CONFIG, 5000);
		configProps.put(ProducerConfig.RECONNECT_BACKOFF_MS_CONFIG, 50);
		configProps.put(ProducerConfig.ACKS_CONFIG, "all");
		// configure the following three settings for SSL Encryption
		/*configProps.put(SslConfigs.SSL_ENDPOINT_IDENTIFICATION_ALGORITHM_CONFIG, "");
		configProps.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, secureProtocol);
		configProps.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, trustStoreConfigFilePath);
		configProps.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, trustStorePassword);*/
		return configProps;
	}

	/**
	 * This method creates the Producer instance.
	 * 
	 * @return KafkaProducer<Long, String>
	 */
	public Producer<Long, String> getProducer(String bootstrapServer) {
		Map<String, Object> props = getProducerProperties();
		props.put(ProducerConfig.CLIENT_ID_CONFIG, producerClientId);
		props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServer);
		return new KafkaProducer<>(props);
	}

}
