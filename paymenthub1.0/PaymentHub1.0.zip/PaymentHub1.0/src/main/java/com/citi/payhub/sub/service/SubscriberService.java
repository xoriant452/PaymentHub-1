package com.citi.payhub.sub.service;

import static com.citi.payhub.util.common.CommonUtils.getMessageMap;
import static com.citi.payhub.util.constant.ConstantUtils.BLANKSTR;
import static com.citi.payhub.util.constant.ConstantUtils.KAFKA;
import static com.citi.payhub.util.constant.ConstantUtils.MQUEUE;
import static com.citi.payhub.util.constant.ConstantUtils.SOURCE_MESSAGE;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.citi.payhub.pub.kafka.KafkaProducer;
import com.citi.payhub.pub.mqueue.MqueueProducer;

@Service
public class SubscriberService {

	@Autowired
	private KafkaProducer kafkaProducer;
	
	@Value("${payhub.produce.config}")
	private String publisherConfig;
	
	@Autowired
	private MqueueProducer mqueueProducer;
	
	
	public void pushMsgToExternalPublisher(String message) {
		Map<String,Object> sourceMsg=getMessageMap(message);
		if(null!=publisherConfig && !BLANKSTR.equalsIgnoreCase(publisherConfig) && KAFKA.equalsIgnoreCase(publisherConfig)) {
			sourceMsg.forEach((msgType,transMessage)->{
				if(!msgType.equalsIgnoreCase(SOURCE_MESSAGE)) {
					kafkaProducer.pushMessageToKafka(transMessage.toString());
				}
			});
		}else if(null!=publisherConfig && !BLANKSTR.equalsIgnoreCase(publisherConfig) && MQUEUE.equalsIgnoreCase(publisherConfig)){
			sourceMsg.forEach((msgType,transMessage)->{
				if(!msgType.equalsIgnoreCase(SOURCE_MESSAGE)) {
					mqueueProducer.publishMessageToQueue(transMessage.toString());
				}
			});
		}
	}
	
	
}
