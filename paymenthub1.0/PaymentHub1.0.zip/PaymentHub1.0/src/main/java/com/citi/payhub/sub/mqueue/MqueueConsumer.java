package com.citi.payhub.sub.mqueue;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

import com.citi.payhub.pub.service.PublisherService;
import com.citi.payhub.sub.kafka.KafkaConsumer;
import com.citi.payhub.sub.service.SubscriberService;
import com.citi.payhub.trans.service.TransformService;

import static com.citi.payhub.util.constant.ConstantUtils.BLANKSTR;
import static com.citi.payhub.util.constant.ConstantUtils.PUBLISHER;
import static com.citi.payhub.util.constant.ConstantUtils.SUBSCRIBER;
import static com.citi.payhub.util.constant.ConstantUtils.TRANSFORMER;

@Component
public class MqueueConsumer {

	private static Logger logger = LogManager.getLogger(KafkaConsumer.class);

	@Value("${payhub.app.behave}")
	private String appBehave;

	@Autowired
	private SubscriberService subscriberService;

	@Autowired
	private TransformService transformService;

	@Autowired
	private PublisherService publisherService;

	@JmsListener(destination = "${spring.activemq.consume.queuename}")
	public void receiveQueue(String message) {
		// String fileName=CommonUtils.getUTER(message);
		// messageTrackerFile.writeMessage(fileName,fileName+TRACK_MQ_CONSUME_MESSAGE);
		// kafkaProducerService.pushMessageToKafka(producerTopic, message, groupId);
		try {
			logger.info("Consumed Message=" + message);
			if (null != appBehave && !BLANKSTR.equalsIgnoreCase(appBehave) && PUBLISHER.equalsIgnoreCase(appBehave)) {
				publisherService.pushMsgToInternalPublisher(message);
			} else if (null != appBehave && !BLANKSTR.equalsIgnoreCase(appBehave)
					&& TRANSFORMER.equalsIgnoreCase(appBehave)) {
				transformService.pushMsgToTransPublisher(message);
			} else if (null != appBehave && !BLANKSTR.equalsIgnoreCase(appBehave)
					&& SUBSCRIBER.equalsIgnoreCase(appBehave)) {
				subscriberService.pushMsgToExternalPublisher(message);
			}
		} catch (Exception e) {
			logger.error(e);
		}

	}
}
