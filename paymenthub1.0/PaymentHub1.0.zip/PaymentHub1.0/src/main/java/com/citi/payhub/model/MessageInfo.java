package com.citi.payhub.model;

import static com.citi.payhub.util.constant.ConstantUtils.DESTINATION_MESSAGE;
import static com.citi.payhub.util.constant.ConstantUtils.SOURCE_MESSAGE;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import com.citi.payhub.exception.PaymentHubException;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
/**
 * @author al99782
 *
 */
public class MessageInfo{
	private String id;
	private String parentId;
	@SerializedName("CREATION_DATE")
	private Date creationDate;
	@SerializedName("INPUT_QUEUE")
	private String inputQueue;
	@SerializedName("APP_ID")
	private String appId;
	@SerializedName("MESSAGE_FORMAT")
	private String messageFormat;
	@SerializedName("MESSAGE_CONTEXT")
	private String messageContext;
	private Map<String, Object> messages = new HashMap<>();
	@Expose(serialize = false, deserialize = false)
	private List<PaymentHubException> paymentHubExceptions = new ArrayList<>();
	@Expose(serialize = false, deserialize = false)
	@SerializedName("ENABLED")
	private boolean enabled;
	@SerializedName("TARGET_KEY")
	private String targetKey;
	private Map<String, String> headers = new HashMap<>();
	private boolean isParserCalled = true;
	
	public MessageInfo() {
		super();
		this.id = UUID.randomUUID().toString();
	}

	public MessageInfo(String rawMessgae) {
		super();
		this.id = UUID.randomUUID().toString();
		this.parentId = this.id;
		this.inputQueue = "GPPSP.PAYHUB.RFRF.REQ";
		this.appId = "";
		this.messageFormat = "";
		this.messages.put(SOURCE_MESSAGE, rawMessgae);
		this.messageContext = "INQUIRY";
		this.creationDate = Calendar.getInstance().getTime();
	}

	public MessageInfo(MessageInfo info) {
		super();
		this.id = info.id;
		this.parentId = info.parentId;
		if(null != info.creationDate) {
			this.creationDate = (Date) info.creationDate.clone();
		}
		this.inputQueue = info.inputQueue;
		this.appId = info.appId;
		this.messageFormat = info.messageFormat;
		this.messageContext = info.messageContext;
		this.enabled = info.enabled;

		Object sourceObject = info.messages.get(SOURCE_MESSAGE);

		if (null != sourceObject) {
			this.messages.put(SOURCE_MESSAGE, sourceObject);
		}

		Object destinationObject = info.messages.get(DESTINATION_MESSAGE);

		if (null != destinationObject) {
			this.messages.put(DESTINATION_MESSAGE, destinationObject);
		}

	}

	public MessageInfo(String inputQueue, String appId, String messageFormat, String messageContext) {
		super();
		this.id = UUID.randomUUID().toString();
		this.parentId = this.id;
		this.inputQueue = inputQueue;
		this.appId = appId;
		this.messageFormat = messageFormat;
		this.messageContext = messageContext;
		this.creationDate = Calendar.getInstance().getTime();
	}

	public MessageInfo(String id, String inputQueue, String appId, String messageFormat, String messageContext) {
		super();
		this.id = (id == null ? UUID.randomUUID().toString() : id);
		this.parentId = this.id;
		this.inputQueue = inputQueue;
		this.appId = appId;
		this.messageFormat = messageFormat;
		this.messageContext = messageContext;
		this.creationDate = Calendar.getInstance().getTime();
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getParentId() {
		return parentId;
	}

	public void setParentId(String parentId) {
		this.parentId = parentId;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public String getInputQueue() {
		return inputQueue;
	}

	public void setInputQueue(String inputQueue) {
		this.inputQueue = inputQueue;
	}

	public String getAppId() {
		return appId;
	}

	public void setAppId(String appId) {
		this.appId = appId;
	}

	public String getMessageFormat() {
		return messageFormat;
	}

	public void setMessageFormat(String messageFormat) {
		this.messageFormat = messageFormat;
	}

	public String getMessageContext() {
		return messageContext;
	}

	public void setMessageContext(String messageContext) {
		this.messageContext = messageContext;
	}

	public Map<String, Object> getMessages() {
		return messages;
	}

	public void setMessages(Map<String, Object> messages) {
		this.messages = messages;
	}

	public List<PaymentHubException> getPaymentHubExceptions() {
		return paymentHubExceptions;
	}

	public void setPaymentHubExceptions(List<PaymentHubException> paymentHubException) {
		this.paymentHubExceptions = paymentHubException;
	}

	public boolean isEnabled() {
		return enabled;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	/**
	 * @return the targetKey
	 */
	public String getTargetKey() {
		return targetKey;
	}

	/**
	 * @param targetKey the targetKey to set
	 */
	public void setTargetKey(String targetKey) {
		this.targetKey = targetKey;
	}

	public Map<String, String> getHeaders() {
		return headers;
	}

	public void setHeaders(Map<String, String> headers) {
		this.headers = headers;
	}

	public boolean isParserCalled() {
		return isParserCalled;
	}

	public void setParserCalled(boolean isParserCalled) {
		this.isParserCalled = isParserCalled;
	}

/*	@Override
	public String toString() {
		return "MessageInfo [id=" + id + ", parentId=" + parentId 
				+ ", creationDate=" + creationDate + ", inputQueue=" + inputQueue + ", appId=" + appId
				+ ", messageFormat=" + messageFormat + ", messageContext=" + messageContext 
				+ ", messages=" + getMessagesToString() + ", headers=" + headers + ", isParserCalled=" + isParserCalled
				+ ", paymentHubExceptions=" + paymentHubExceptions + ", enabled=" + enabled + "]";
	}

	private String getMessagesToString() {
		try {
			StringBuilder builder = new StringBuilder();
			builder.append("{" + messages.keySet());
			for (Entry<String, Object> entry : messages.entrySet()) {
				if(entry.getValue() instanceof String) {
					String messageString = entry.getValue().toString();
					int maxLength = (messageString.length() < MAX_CHAR) ? messageString.length() : MAX_CHAR;
					builder.append("\r\n[" + entry.getKey() + "=" + messageString.substring(0, maxLength) + "],");
				} else if (entry.getValue() instanceof MessageInfo) {
					for(Entry<String, Object> entry2 :  ((MessageInfo)entry.getValue()).getMessages().entrySet()){
						String messageString = entry2.getValue().toString();
						int maxLength = (messageString.length() < MAX_CHAR) ? messageString.length() : MAX_CHAR;
						builder.append("\r\n[" + entry.getKey() + "=" + messageString.substring(0, maxLength) + "],");
					}
				}
			}
			builder.append("}");
			return builder.toString();
		} catch (Throwable e) {
			return messages.toString();
		}
	}*/
	
	//public static void main(String[] args) throws FileNotFoundException {
		//System.out.println(new MessageInfo("yogesh").toString());
		/*Gson gson = new Gson();
		//String s=gson.toJson(new MessageInfo("yogesh"));
		String s="{\"id\":\"b9161e6b-89ae-4496-9398-593594826ebf\",\"parentId\":\"b9161e6b-89ae-4496-9398-593594826ebf\",\"CREATION_DATE\":\"Dec 20, 2018 10:57:46 AM\",\"INPUT_QUEUE\":\"GPPSP.PAYHUB.RFRF.REQ\",\"APP_ID\":\"\",\"MESSAGE_FORMAT\":\"\",\"MESSAGE_CONTEXT\":\"INQUIRY\",\"messages\":{\"SOURCE_MESSAGE\":\"{\\u0027UTER\\u0027: \\u00271545283655901-Test\\u0027,\\u0027ACC_NUMBER\\u0027:\\u00271\\u0027,\\u0027CREATION_DATETIME\\u0027: \\u002720 Dec 2018 10:57:35\\u0027,\\u0027FLOW_CONTEXT\\u0027: \\u0027ER_TO_PAC\\u0027,\\u0027INPUT_QUEUE\\u0027: \\u0027FileNameParser\\u0027,\\u0027APP_ID\\u0027:\\u0027/opt/phubstore/incoming/cbr\\u0027, \\u0027EXCEPTION_type\\u0027:\\u0027Transformation\\u0027, \\u0027TRANSFORMED_KAY\\u0027:\\u0027ERROR_MESSAGE\\u0027, \\u0027REPLAY_STATUS\\u0027:\\u0027NEW\\u0027, \\u0027MESSAGE\\u0027:\\u0027Veggie redirects here. For the diet that abstains from animal products and consists mostly of plants see Veganism.Veggie redirects here. For the diet that abstains from animal products and consists mostly of plants see Veganism. For a vegetarian diet see Vegetarianism.\\u0027}\"},\"paymentHubExceptions\":[],\"ENABLED\":false,\"headers\":{},\"isParserCalled\":true}";
		//System.out.println(s);
		MessageInfo messageInfo = gson.fromJson(s, MessageInfo.class);
		Map<String,Object> str=(Map<String, Object>) messageInfo.getMessages();
		System.out.println(str);
		*/
		
		
		/*Map<String, Integer> items = new HashMap<>();
		items.put("A", 10);
		items.put("B", 20);
		items.put("C", 30);
		items.put("D", 40);
		items.put("E", 50);
		items.put("F", 60);
		
		//items.forEach((k,v)->System.out.println("Item : " + k + " Count : " + v));
		
		items.forEach((kk,vv)->{
			System.out.println("Item : " + kk + " Count : " + vv);
			if("E".equals(kk)){
				System.out.println("Hello E");
			}
		});*/
		
/*		FileReader f=new FileReader("E:\\test.txt");
		BufferedReader br=new BufferedReader(f);*/
	//}
}
