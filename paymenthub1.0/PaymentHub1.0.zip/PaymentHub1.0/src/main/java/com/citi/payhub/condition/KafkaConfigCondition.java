package com.citi.payhub.condition;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.context.annotation.Condition;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.core.type.AnnotatedTypeMetadata;

import com.citi.payhub.util.constant.ConstantUtils;


public class KafkaConfigCondition implements Condition{

	
	private static Logger logger = LogManager.getLogger(KafkaConfigCondition.class);
	
	@Override
	public boolean matches(ConditionContext context, AnnotatedTypeMetadata metadata) {
		String config=context.getEnvironment().getProperty("payhub.consume.config");
		if(null!=config && !ConstantUtils.BLANKSTR.equalsIgnoreCase(config)) {
			logger.info("I am in Kafka");
			return config.equalsIgnoreCase(ConstantUtils.KAFKA);
		}
		return false;
	}
}
