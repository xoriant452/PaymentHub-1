package com.citi.payhub.sub.kafka;

import static com.citi.payhub.util.constant.ConstantUtils.BLANKSTR;
import static com.citi.payhub.util.constant.ConstantUtils.PUBLISHER;
import static com.citi.payhub.util.constant.ConstantUtils.SUBSCRIBER;
import static com.citi.payhub.util.constant.ConstantUtils.TRANSFORMER;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;

import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.citi.payhub.pub.service.PublisherService;
import com.citi.payhub.sub.config.KafkaConsumerConfig;
import com.citi.payhub.sub.service.SubscriberService;
import com.citi.payhub.trans.service.TransformService;

@Component
public class KafkaConsumer {

	private static Logger logger = LogManager.getLogger(KafkaConsumer.class);

	@Autowired
	private KafkaConsumerConfig kafkaConsumerConfig;

	@Value("${spring.kafka.consume.bootstrapServer}")
	private String bootstrapServer;

	@Value("${spring.kafka.consume.topic}")
	private String consumeTopics;

	@Value("${spring.kafka.consumergroup.id}")
	private String groupId;

	@Autowired
	private SubscriberService subscriberService;
	@Autowired
	private TransformService transformService;
	@Autowired
	private PublisherService publisherService;

	@Value("${payhub.app.behave}")
	private String appBehave;

	public void receiveKafkaMessage() {
		try {
		List<String> topicList = Arrays.asList(consumeTopics.split(","));
		Consumer<Long, String> consumer = kafkaConsumerConfig.createConsumer(topicList, bootstrapServer, groupId);
		while (true) {
			ConsumerRecords<Long, String> records = null;
			try {
				records = consumer.poll(Duration.ofMillis(100));
			} catch (Exception e) {
				logger.error(e);
			}
			consumer.commitSync();
			if (null != records && !records.isEmpty()) {
				for (ConsumerRecord<Long, String> record : records) {
					String message = record.value();
					logger.info("Consumed Message="+message);
					if (null != appBehave && !BLANKSTR.equalsIgnoreCase(appBehave)
							&& PUBLISHER.equalsIgnoreCase(appBehave)) {
						publisherService.pushMsgToInternalPublisher(message);
					} else if (null != appBehave && !BLANKSTR.equalsIgnoreCase(appBehave)
							&& TRANSFORMER.equalsIgnoreCase(appBehave)) {
						transformService.pushMsgToTransPublisher(message);
					} else if (null != appBehave && !BLANKSTR.equalsIgnoreCase(appBehave)
							&& SUBSCRIBER.equalsIgnoreCase(appBehave)) {
						subscriberService.pushMsgToExternalPublisher(message);
					}
				}
			}
		}
		}catch(Exception e) {
			logger.error(e);
		}
	}

}
