package com.citi.payhub.pub.service;

import static com.citi.payhub.util.constant.ConstantUtils.BLANKSTR;
import static com.citi.payhub.util.constant.ConstantUtils.KAFKA;
import static com.citi.payhub.util.constant.ConstantUtils.MQUEUE;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.citi.payhub.model.MessageInfo;
import com.citi.payhub.pub.kafka.KafkaProducer;
import com.citi.payhub.pub.mqueue.MqueueProducer;
import com.google.gson.Gson;

@Service
public class PublisherService {

	@Autowired
	private KafkaProducer producerService;
	
	@Value("${payhub.produce.config}")
	private String publisherConfig;
	
	@Autowired
	private MqueueProducer mqueueProducer;
	
	private Gson gson = new Gson();
	
	public void pushMsgToInternalPublisher(String message)throws Exception{
		String msgInfo=gson.toJson(new MessageInfo(message));
		if(null!=publisherConfig && !BLANKSTR.equalsIgnoreCase(publisherConfig) && KAFKA.equalsIgnoreCase(publisherConfig)) {
			producerService.pushMessageToKafka(msgInfo);
		}else if(null!=publisherConfig && !BLANKSTR.equalsIgnoreCase(publisherConfig) && MQUEUE.equalsIgnoreCase(publisherConfig)){
			mqueueProducer.publishMessageToQueue(msgInfo);
		}
	}
}
