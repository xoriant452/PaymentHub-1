package com.citi.payhub.sub.config;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.serialization.LongDeserializer;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

/**
 * Kafka Consumer Config
 * 
 * @author Yogesh Mohite
 * @CreationDate 26/11/2018
 * @version 1.0
 */
@Lazy
@Component
public class KafkaConsumerConfig {

	@Value("${spring.kafka.isolation}")
	String isolationLevel;

	@Value("${spring.kafka.autooffset}")
	String autoOffsetReset;

	@Value("${spring.kafka.autocommit}")
	String autoCommit;
	
	@Value("${security.config.protocol}")
	String secureProtocol;

	@Value("${ssl.truststore.location.config.file.path}")
	String trustStoreConfigFilePath;
	
	@Value("${ssl.truststore.password.config}")
	String trustStorePassword;

	@PostConstruct
	private Map<String, Object> setBootStrapProperties() {
		Map<String, Object> props = new HashMap<>();
		props.put(ConsumerConfig.ISOLATION_LEVEL_CONFIG, isolationLevel);
		props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, autoOffsetReset);
		props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, autoCommit);
		props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, LongDeserializer.class.getName());
		props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
		// configure the following three settings for SSL Encryption
	/*	props.put(SslConfigs.SSL_ENDPOINT_IDENTIFICATION_ALGORITHM_CONFIG, "");
		props.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, secureProtocol);
		props.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, trustStoreConfigFilePath);
		props.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, trustStorePassword);*/
		
		return props;
	}

	public Consumer<Long, String> createConsumer(List<String> topic, String bootstrapServer, String groupId) {
		Map<String, Object> props = setBootStrapProperties();
		props.put(ConsumerConfig.GROUP_ID_CONFIG, groupId);
		props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServer);
		Consumer<Long, String> consumer = new KafkaConsumer<>(props);
		consumer.subscribe(topic);
		return consumer;
	}

}
