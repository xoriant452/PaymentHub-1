package com.citi.payhub.pub.kafka;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutionException;

import javax.annotation.PostConstruct;

import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.citi.payhub.pub.config.KafkaProducerConfig;

@Component
public class KafkaProducer {

	private Logger logger = LogManager.getLogger(KafkaProducer.class);

	@Value("${spring.kafka.produce.bootstrapServer}")
	private String bootstrapServer;

	@Value("${spring.kafka.error.topic}")
	private String errorTopic;

	@Value("${spring.kafka.produce.topic}")
	private String producerTopic;

	@Autowired
	private KafkaProducerConfig kafkaProducerConfig;

	/*
	 * @Autowired MessageTrackerFile messageTrackerFile;
	 */

	private Producer<Long, String> producer;

	@PostConstruct
	public void initProducer() {
		producer = kafkaProducerConfig.getProducer(bootstrapServer);
	}

	public void pushMessageToKafka(String message) {
		List<String> topicList = Arrays.asList(producerTopic.split(","));
		for (String topicName : topicList) {
			final ProducerRecord<Long, String> record = new ProducerRecord<>(topicName, message);
			try {
				producer.send(record).get();
			} catch (Exception e) {
				// messageTrackerFile.writeMessage(fileName,fileName+ConstantUtils.ERROR_KAFKA_TRACK_CONSUME_MESSAGE
				// + bootstrapServer);
				final ProducerRecord<Long, String> errorRecord = new ProducerRecord<>(errorTopic, message);
				try {
					producer.send(errorRecord).get();
				} catch (InterruptedException | ExecutionException e1) {
					logger.error(e1);
				}
				logger.error(e);
			}
		}
	}

}
