package com.citi.payhub.util.common;

import java.util.Map;

import com.citi.payhub.model.MessageInfo;
import com.google.gson.Gson;

public class CommonUtils {

	private static Gson gson = new Gson();
	
	public static Map<String,Object> getMessageMap(String message) {
		MessageInfo messageInfo = gson.fromJson(message, MessageInfo.class);
		return (Map<String,Object>) messageInfo.getMessages();
	}
	
}
