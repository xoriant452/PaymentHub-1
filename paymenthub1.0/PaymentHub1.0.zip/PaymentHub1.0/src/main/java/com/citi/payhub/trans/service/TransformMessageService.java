package com.citi.payhub.trans.service;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;

import javax.annotation.PostConstruct;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class TransformMessageService {

	private static Logger logger = LogManager.getLogger(TransformMessageService.class);

	@Value("${payhub.transform.message.jar.path}")
	private String transformMessageJarPath;

	@Value("${payhub.transform.method.name}")
	private String transformMethodName;

	@Value("${payhub.transform.class.path}")
	private String transformClassPath;

	private Class<?> beanClass = null;

	private Object beanObj = null;

	@PostConstruct
	private void getTransformMsgInstance() {
		try {
			URL[] classLoaderUrls = new URL[] { new URL("file:///" + transformMessageJarPath) };
			URLClassLoader urlClassLoader = URLClassLoader.newInstance(classLoaderUrls,
					TransformMessageService.class.getClassLoader());
			beanClass = Class.forName(transformClassPath, true, urlClassLoader);
			Constructor<?> constructor = beanClass.getConstructor();
			beanObj = constructor.newInstance();
		} catch (Exception e) {
			logger.error(e);
		}
	}

	public String getTransferedMessage(String message) throws Exception {
		Method method = beanClass.getDeclaredMethod(transformMethodName, String.class);
		method.setAccessible(true);
		String str = (String) method.invoke(beanObj, message);
		System.out.println(str);
		return str;
	}

	/*public String sendTransformMessageFirst(String message) {
		String transStr = "";
		try {
			transStr = getTransferedMessage(message);
		} catch (Exception e) {
			e.printStackTrace();
		}
		logger.info("Received Message1 ={}\n", transStr);
		return transStr;
	}

	public String sendTransformMessageSecond(String message) {
		String transStr = message.replace("{", "<").replace("}", ">");
		// logger.info("Received Message2 ={}\n", transStr);
		return transStr;
	}*/

}
