package com.citi.payhub.pub.mqueue;

import java.util.Arrays;
import java.util.List;

import javax.jms.Queue;

import org.apache.activemq.command.ActiveMQQueue;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;

@Component
public class MqueueProducer {

	
	@Autowired
	private JmsTemplate jmsTemplate;

	@Value("${spring.activemq.produce.queuename}")
	private String destinationQueue;
	
	
	private Queue getQueue(String queue) {
		return new ActiveMQQueue(queue);
	}

	public void publishMessageToQueue(String message) {
		List<String> queueList = Arrays.asList(destinationQueue.split(","));
		for (String queueName : queueList) {
		jmsTemplate.convertAndSend(getQueue(queueName),message);
		}
	}
	
}
