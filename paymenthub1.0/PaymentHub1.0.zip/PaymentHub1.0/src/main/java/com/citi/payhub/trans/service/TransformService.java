package com.citi.payhub.trans.service;

import static com.citi.payhub.util.common.CommonUtils.getMessageMap;
import static com.citi.payhub.util.constant.ConstantUtils.BLANKSTR;
import static com.citi.payhub.util.constant.ConstantUtils.KAFKA;
import static com.citi.payhub.util.constant.ConstantUtils.MQUEUE;
import static com.citi.payhub.util.constant.ConstantUtils.SOURCE_MESSAGE;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.citi.payhub.pub.kafka.KafkaProducer;
import com.citi.payhub.pub.mqueue.MqueueProducer;

@Service
public class TransformService {

	@Autowired
	private KafkaProducer kafkaProducer;

	@Autowired
	private TransformMessageService transformMessageService;

	@Value("${payhub.produce.config}")
	private String publisherConfig;

	@Autowired
	private MqueueProducer mqueueProducer;

	public void pushMsgToTransPublisher(String message) throws Exception {
		Map<String, Object> sourceMsg = getMessageMap(message);
		String transformedMsg = sendTransformMessageToKafka(sourceMsg.get(SOURCE_MESSAGE).toString());
		if (null != publisherConfig && !BLANKSTR.equalsIgnoreCase(publisherConfig)
				&& KAFKA.equalsIgnoreCase(publisherConfig)) {
			kafkaProducer.pushMessageToKafka(transformedMsg);
		} else if (null != publisherConfig && !BLANKSTR.equalsIgnoreCase(publisherConfig)
				&& MQUEUE.equalsIgnoreCase(publisherConfig)) {
			mqueueProducer.publishMessageToQueue(transformedMsg);
		}
	}

	private String sendTransformMessageToKafka(String message) throws Exception {
		return transformMessageService.getTransferedMessage(message);
	}

}
