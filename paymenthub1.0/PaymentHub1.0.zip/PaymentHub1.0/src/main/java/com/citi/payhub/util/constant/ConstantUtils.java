package com.citi.payhub.util.constant;

public class ConstantUtils {

	public static final String KAFKA="kafka";
	public static final String MQUEUE="mqueue";
	public static final String RESTAPI="restapi";
	public static final String FILE="file";
	public static final String BLANKSTR="";
	public static final String LINE_SEPARATOR="line.separator";
	public static final String UTER="UTER";
	public static final String TRACK_KAFKA_CONSUME_MESSAGE="- Message consumed from kafka server ";
	public static final String ERROR_KAFKA_TRACK_CONSUME_MESSAGE="- Error occures while consuming message from kafka server ";
	public static final String TRACK_KAFKA_PRODUCE_MESSAGE="- Message produced on kafka server ";
	public static final String TRACK_MQ_CONSUME_MESSAGE="- Message consumed from kafka server ";
	public static final String ERROR_MQ_TRACK_CONSUME_MESSAGE="- Error occures while consuming message from kafka server ";
	public static final String TRACK_MQ_PRODUCE_MESSAGE="- Message produced on kafka server ";
	public static final String TRACK_SEND_TRANSFORM_MESSAGE="- Message has sent for transformation.";
	public static final String TRACK_SUCCESS_TRANSFORM_MESSAGE="- Message has been transformed.";
	
	public static final String DESTINATION_MESSAGE="DESTINATION_MESSAGE";
	public static final int MAX_CHAR=5000;
	public static final String SOURCE_MESSAGE="SOURCE_MESSAGE";
	public static final String MESSAGES="messages";
	public static final String PUBLISHER="pub";
	public static final String TRANSFORMER="trans";
	public static final String SUBSCRIBER="sub";
	
	
}
