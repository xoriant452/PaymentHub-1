package com.kafkaproducer.KafkaProducer;

import java.util.Properties;

import javax.annotation.PostConstruct;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.KafkaException;
import org.apache.kafka.common.serialization.StringSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
@EnableScheduling
class TxProducer {
	
	@Value("${spring.producer.topicName}")
	String topic;
	
	@Value("${spring.producer.bootstrapServer}")
	String bootstrapServer;
	
	@Value("${spring.producer.clientId}")
	String clientId;
	
	@Value("${spring.producer.transactionId}")
	String transactionId;

	int noOfMessages = 1;
	private Producer<String, String> producer;
	long delay = 1_000;
	static int number = 0;
	private static final Logger logger = LoggerFactory.getLogger(TxProducer.class);

	/**
	 * This method will send the message every 3 seconds
	 */
	@Scheduled(fixedRate = 3000)
	void sendMessage() {
		try {
			producer.beginTransaction(); // begin transactions
			for (int i=0; i< noOfMessages; i++) {
				logger.info("Sending msg from TxProducer: " + number);
				producer.send(new ProducerRecord<String, String>(topic, "" + number, getEvent("string", number)));
				number++;
				try {
					Thread.sleep(delay);
				} catch (InterruptedException e) {
				}
			}
			producer.commitTransaction(); // commit

		} catch (KafkaException e) {
			// For all other exceptions, just abort the transaction and try again.
			producer.abortTransaction();
		}
	}

	/**
	 * @return Producer<String, String>
	 * This method will create idempotent producer instance
	 */
	@PostConstruct
	void createProducer() {
		Properties producerConfig = new Properties();
		producerConfig.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServer);
		producerConfig.put(ProducerConfig.CLIENT_ID_CONFIG, clientId);
		producerConfig.put(ProducerConfig.ENABLE_IDEMPOTENCE_CONFIG, true); // enable idempotence
		producerConfig.put(ProducerConfig.TRANSACTIONAL_ID_CONFIG, transactionId); // set transaction id
		producerConfig.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
		producerConfig.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);

		producer = new KafkaProducer<>(producerConfig);
		producer.initTransactions();
	}

	private static String getEvent(String messageType, int i) {
		return "RealTime Producer-Message Number-" + i;
	}
}
