package com.kafkaconsumer.KafkaConsumer;

import java.util.Collections;
import java.util.Properties;

import javax.annotation.PostConstruct;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class TxConsumer {
	
	@Value("${spring.consumer.topic}")
	String topic;
	
	@Value("${spring.consumer.bootstrapServer}")
	String bootstrapServer;
	
	@Value("${spring.consumer.consumergroup.id1}")
	String groupId;
	
	@Value("${spring.consumer.isolation}")
	String isolationLevel;
	
	@Value("${spring.consumer.autooffset}")
	String autoOffsetReset;

	private static final Logger logger = LoggerFactory.getLogger(TxConsumer.class);
	KafkaConsumer<String, String> consumer;

	void receiveMessage() {
		while (true) {
			ConsumerRecords<String, String> records = consumer.poll(0);
			for (ConsumerRecord<String, String> record : records) {
				logger.info("Received Message topic ={}, partition ={}, offset = {}, key = {}, value = {}\n", record.topic(), record.partition(), record.offset(), record.key(), record.value());
			}
			consumer.commitSync();
		}

	}

	@PostConstruct
	void createConsumer() {
		Properties consumerConfig = new Properties();
		consumerConfig.put("group.id", groupId);
		consumerConfig.put("bootstrap.servers", bootstrapServer);
		consumerConfig.put("auto.offset.reset", autoOffsetReset);
		consumerConfig.put(ConsumerConfig.ISOLATION_LEVEL_CONFIG, isolationLevel);
		consumerConfig.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
		consumerConfig.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);

		consumer = new KafkaConsumer<>(consumerConfig);
		consumer.subscribe(Collections.singletonList(topic));
		this.receiveMessage();
	}
}