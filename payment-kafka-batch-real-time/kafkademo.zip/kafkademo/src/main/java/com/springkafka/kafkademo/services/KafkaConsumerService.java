package com.springkafka.kafkademo.services;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

import javax.annotation.PostConstruct;

import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.consumer.OffsetAndMetadata;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.serialization.BytesDeserializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import com.springkafka.kafkademo.config.KafkaProducerConfig;
import com.springkafka.kafkademo.transaction.IProcessRecord;;

/**
 * @author wani_p
 *
 */
@EnableScheduling
@Component
public class KafkaConsumerService implements IProcessRecord{
	
	private static final Logger logger = LoggerFactory.getLogger(KafkaConsumerService.class);
	private static int id=0;
	
	@Value("${spring.kafka.topic}")
	String topic;
	
	@Value("${spring.kafka.reconciliation}")
	String reconcilliationTopic;
	
	@Value("${spring.kafka.success.topic}")
	String successTopic;
	
	@Value("${spring.kafka.topic1}")
	String topic1;
	
	@Value("${spring.kafka.topic2}")
	String topic2;
	
	@Value("${spring.kafka.fail.topic}")
	String failTopic;
	
	@Value("${spring.kafka.bootstrapServer}")
	String bootstrapServer;
	
	@Value("${spring.kafka.consumergroup.id1}")
	String groupId;
	
	@Value("${spring.kafka.isolation}")
	String isolationLevel;
	
	@Value("${spring.kafka.autooffset}")
	String autoOffsetReset;
	
	@Value("${spring.kafka.autocommit}")
	String autoCommit;
	
	@Autowired
	private KafkaProducerConfig producerConfig;
	
	@Autowired
	private KafkaTemplate<String, String> kafkaTemplate;
	
	private Consumer<String,String> consumer;
	private Producer<String,String> producer;
	
	AtomicBoolean initConsumerFlag = new AtomicBoolean();
	AtomicBoolean initProducerFlag = new AtomicBoolean();
	long delay = 1_000 ; // delay in messages
	
	/**
	 * This method will initialize the Producer
	 */
	public void initProducer(){
		if (!initProducerFlag.get()) {
			producer = producerConfig.createProducer();
			initProducerFlag.set(true);
			producer.initTransactions();
		}
	}
	
	/**
	 * This method will run periodically every 30 seconds and will consume all the messages
	 */
	@Scheduled(fixedRate = 30000)
	public void receiveMessage() {
		boolean isMessageProcessed=false;
            ConsumerRecords<String,String> records = consumer.poll(100);
            for (ConsumerRecord<String,String> record : records) {
                logger.info("Received Message topic ={}, partition ={}, offset = {}, key = {}, value = {}\n", record.topic(), record.partition(), record.offset(), record.key(), record.value());
                String value = String.valueOf(record.value());
                isMessageProcessed = this.processMessage(value);
                boolean isSuccess = this.sendTransformedMessage(isMessageProcessed,value,record.offset());
                if(!isSuccess) {
                	this.rollBack(value);
                	}
                }
           }

	/**
	 * @param isMessageProcessed
	 * @param record
	 * @param offset 
	 * @return
	 * This method will send transformed data to another topic
	 */
	private boolean sendTransformedMessage(boolean isMessageProcessed, String record, long offset) {
		if(!initProducerFlag.get()) {
			logger.info("Producer flag : {} ", initProducerFlag);
			initProducer();
			logger.info("Producer flag after initialisation : {} ", initProducerFlag);
		}
		
		Map<TopicPartition, OffsetAndMetadata> groupCommit = new HashMap<TopicPartition, OffsetAndMetadata>();
		groupCommit.put(new TopicPartition(topic, 0), new OffsetAndMetadata(offset + 1, null));
		
		//Sending record to reconciliation topic without any transaction
		kafkaTemplate.send(reconcilliationTopic,getEvent("string", id,record));
		//Begin Transaction
		producer.beginTransaction();
		if(isMessageProcessed) {
			producer.send(new ProducerRecord<String,String>(successTopic, getKey(id), getEvent("string", id,record)));
			producer.send(new ProducerRecord<String, String>(topic1, getKey(id),getEvent("string", id, record)));
			producer.send(new ProducerRecord<String, String>(topic2, getKey(id),getEvent("string", id, record)));
			logger.info("Record successfully sent to success , topic1 and topic 2 topics");
			producer.sendOffsetsToTransaction(groupCommit, groupId);
			producer.commitTransaction();
			id++;
			return true;
		}else {
			producer.send(new ProducerRecord<String,String>(failTopic, getKey(id), getEvent("string", id,record)));
			logger.error("Record sent to fail topic");
			producer.sendOffsetsToTransaction(groupCommit, groupId);
			producer.commitTransaction();
			id++;
			return false;
		}
	}

	/* (non-Javadoc)
	 * @see com.springkafka.kafkademo.transaction.Transaction#processMessage(java.lang.String)
	 * This method will process the record and will create a file
	 */
	@Override
	public boolean processMessage(String record) {
		
		File file = new File("/ndm/"+record+".txt");
		//File file = new File("F://KafkaTestFiles//"+record+".txt");
		try {
			if(file.createNewFile()) {
				return true;
			}else {
				logger.error("File name: {}",record," already exist");
				return false;
			}
		}catch(IOException e) {
			logger.error("Exception occured while processing the record");
			e.printStackTrace();
			this.rollBack(record);
		}
		return false;
	}
	
	@Override
	public void rollBack(String record) {
		try {
			//Files.deleteIfExists(Paths.get("F://KafkaTestFiles//"+record+".txt"));
			Files.deleteIfExists(Paths.get("/ndm/"+record+".txt"));
			//File file = new File("F://KafkaTestFiles//New-"+record+".txt");
			File file = new File("/ndm/New-"+record+".txt");
			if(file.createNewFile()) {
				logger.info("New file: New-{}",record," created successfully");
			}else {
				logger.error("Error while creating new file: New-{}",record);
			}
		} catch (IOException e) {
			logger.error("Exception occured. Roll back done.");
			e.printStackTrace();
		}
	}
	
	private static String getEvent(String messageType, int i, String record) {
		return "Msg-"+i+": "+record;
    }
	
	 private static String getKey(int i) {
	        return ""+i;
	    }
	 
	 @PostConstruct
	    public void createConsumer() {
	        Map<String, Object> props = new HashMap<>();
	        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServer);
	        props.put(ConsumerConfig.GROUP_ID_CONFIG, groupId);
	        props.put(ConsumerConfig.ISOLATION_LEVEL_CONFIG, isolationLevel);
	        props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, autoOffsetReset);
	        props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, autoCommit);
	        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, BytesDeserializer.class);
	        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, BytesDeserializer.class);
	        
	        consumer = new KafkaConsumer<>(props);
	        // Subscribe to the topic.
	        consumer.subscribe(Collections.singletonList(topic));
	    }
}
