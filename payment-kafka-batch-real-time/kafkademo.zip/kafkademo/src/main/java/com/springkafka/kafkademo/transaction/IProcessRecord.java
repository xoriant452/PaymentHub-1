package com.springkafka.kafkademo.transaction;

public interface IProcessRecord {
	
	boolean processMessage(String message);
	
	void rollBack(String record);
}
