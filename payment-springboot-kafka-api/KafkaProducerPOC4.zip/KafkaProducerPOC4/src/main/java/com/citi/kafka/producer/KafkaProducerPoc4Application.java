package com.citi.kafka.producer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KafkaProducerPoc4Application{

	public static void main(String[] args) {
		SpringApplication.run(KafkaProducerPoc4Application.class, args);
	}
	
}
