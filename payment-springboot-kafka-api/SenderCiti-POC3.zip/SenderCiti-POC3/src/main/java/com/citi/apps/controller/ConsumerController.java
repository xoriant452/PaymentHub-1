package com.citi.apps.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

import com.citi.apps.producer.KafkaTxProducer;

@Component
public class ConsumerController {
	
	@Autowired
	private KafkaTxProducer kafkaTxProducer;

	@JmsListener(destination = "STANDALONE.QUEUE")
	public void consume(String message) {
		System.out.println("Consuming message from MQ: " + message);
		kafkaTxProducer.sendMessage(message);
	}

}
