package com.citi.apps.controller;

import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

@Component
public class ConsumerController {

	@JmsListener(destination = "STANDALONE.QUEUE")
	public void consume(String message) {
		System.out.println("Message consumed:- " + message);
	}

}
