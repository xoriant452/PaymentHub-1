package com.citi.apps;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.citi.apps.Service.MessageService;

/**
 * @author clouduser This class is the entry point to start MQ Sender service
 *         and send message to MQ
 */
@SpringBootApplication
public class SenderCitiPoc2Application implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(SenderCitiPoc2Application.class, args);
	}

	@Autowired
	MessageService service;

	@Override
	public void run(String... args) throws Exception {
		service.publish();
	}

}
