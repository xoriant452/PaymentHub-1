package com.citi.apps;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;

/**
 * 
 * @author clouduser
 * Main class
 */
@SpringBootApplication
@EntityScan( basePackages = {"com.citi.apps.common.vo"} )
public class App1RestCallDockerApplication {

	public static void main(String[] args) {
		SpringApplication.run(App1RestCallDockerApplication.class, args);
	}
}
