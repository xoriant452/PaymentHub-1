package com.citi.apps.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.citi.apps.common.vo.HelloVO;

public interface HelloDao extends JpaRepository<HelloVO, String>{
	
	
}
