package com.citi.apps.service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.citi.apps.common.exception.AppDAOException;
import com.citi.apps.common.vo.HelloVO;
import com.citi.apps.dao.HelloDao;

@Service
public class HelloService {
	
	@Autowired
	HelloDao helloDao;
	/**
	 * Method insert date to database when request come 
	 * @throws AppDAOException
	 */
	public void insertTimeStamp() throws AppDAOException {
		Date date = new Date();
	    SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");  
	    String strDate= formatter.format(date);  
	    System.out.println(strDate);  
	    HelloVO helloVo = new HelloVO();
	    helloVo.setDateClm(strDate);
	    Random rand = new Random(); 
	    
        // Generate random integers in range 0 to 999 
        int rand_int1 = rand.nextInt(1000); 
	    helloVo.setId(rand_int1);
	    int rand_int2 = rand.nextInt(1000);
	    helloVo.setExtraF1(rand_int2);
	    System.out.println("calling Save method to insert into database");
	    helloDao.saveAndFlush(helloVo);
	    System.out.println("Saved in oracle database");
	}
}
