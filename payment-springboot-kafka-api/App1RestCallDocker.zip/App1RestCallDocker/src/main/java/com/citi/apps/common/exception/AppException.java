package com.citi.apps.common.exception;

/**
 * This exception custom class is used to handle the service and controller
 * layer exception for Citi insight Application
 * 
 * @author clouduser
 *
 */
public class AppException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8091549299651313556L;

	private String errorMsg = "APP MSG Exception: [";

	/**
	 * Create a new instance of <code>AppException</code> with the specified
	 * detail message
	 */
	public AppException() {
		super();
	}

	/**
	 * Constructor an instance of <code>AppException</code> with the specified
	 * detail message
	 * 
	 * @param msg
	 *            the detail message
	 */
	public AppException(String msg) {
		super(msg);
		this.errorMsg += msg;
	}

	/**
	 * @param exception
	 */
	public AppException(Exception exception) {
		super(exception);
		this.errorMsg += exception.toString();
	}

	/**
	 * @param throwable
	 */
	public AppException(Throwable throwable) {
		super(throwable);
		this.errorMsg += throwable.toString();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "AppException [errorMsg=" + errorMsg + "]";
	}

}
