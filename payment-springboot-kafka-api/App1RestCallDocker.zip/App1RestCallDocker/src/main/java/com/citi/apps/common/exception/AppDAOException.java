package com.citi.apps.common.exception;

/**
 * This exception custom class for database access object exception for Citi
 * insight Application
 * 
 * @author clouduser
 *
 */
public class AppDAOException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4498938799062208550L;

	private String errorMsg = "APP MSG DAO Exception: [";

	/**
	 * Create a new instance of <code>AppDAOException</code> with the specified
	 * detail message
	 */
	public AppDAOException() {
		super();
	}

	/**
	 * Constructor an instance of <code>AppDAOException</code> with the specified
	 * detail message
	 * 
	 * @param msg
	 *            the detail message
	 */
	public AppDAOException(String msg) {
		super(msg);
		this.errorMsg += msg;
	}
	
	/**
	 * @param exception
	 */
	public AppDAOException(Exception exception) {
		super(exception);
		this.errorMsg += exception.toString();
	}
	
	/**
	 * @param throwable
	 */
	public AppDAOException(Throwable throwable) {
		super(throwable);
		this.errorMsg += throwable.toString();
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "AppDAOException [errorMsg=" + errorMsg + "]";
	}
	
	

}
