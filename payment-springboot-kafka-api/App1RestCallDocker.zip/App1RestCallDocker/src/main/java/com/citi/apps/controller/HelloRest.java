package com.citi.apps.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.citi.apps.common.exception.AppDAOException;
import com.citi.apps.service.HelloService;
/**
 * 
 * @author clouduser
 * Rest Controller
 */
@RestController
public class HelloRest {
	
	@Autowired
	HelloService helloService;

	@GetMapping(value="/getMsg")
	public String getMessage() {
		try {
			helloService.insertTimeStamp();
		} catch (AppDAOException e) {
			e.printStackTrace();
		}
		return "Hello World";
	}

	@GetMapping(value="/")
	public String getMsg() {
		try {
			helloService.insertTimeStamp();
		} catch (AppDAOException e) {
			e.printStackTrace();
		}
		return "Hello World";
	}
}
