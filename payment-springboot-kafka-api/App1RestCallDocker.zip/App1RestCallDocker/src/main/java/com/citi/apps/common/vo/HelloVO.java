package com.citi.apps.common.vo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
/**
 * 
 * @author clouduser
 * Entity Class 
 */
@Entity
@Table(name="HelloDB")
public class HelloVO {
	
	
	@Id
	@Column(name="ID")
	private Integer id;
	
	@Column(name="DATECLM")
	private String dateClm;
	
	@Column(name="EXTRAF1")
	 	private Integer extraF1;
	
	public HelloVO() {
		// TODO Auto-generated constructor stub
	}
	/**
	 * @return the dateClm
	 */
	public String getDateClm() {
		return dateClm;
	}

	/**
	 * @param dateClm the dateClm to set
	 */
	public void setDateClm(String dateClm) {
		this.dateClm = dateClm;
	}

	/**
	 * @return the extraF1
	 */
	public Integer getExtraF1() {
		return extraF1;
	}

	/**
	 * @param extraF1 the extraF1 to set
	 */
	public void setExtraF1(Integer extraF1) {
		this.extraF1 = extraF1;
	}

	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}
	
	

}
