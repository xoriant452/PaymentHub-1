import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { hostName } from '../shared/hostName';

@Injectable({
  providedIn: 'root'
})
export class HistoryService {
  host: string;
  revieweUrl: string;

  constructor(private http: HttpClient) { 
    this.host = hostName;
    this.revieweUrl = this. host + "historyReportData";
  }

  // Returns the list of history messages if any.
  getHistoryMessages(pageNo, perPage) {
    let serviceUrl = this.revieweUrl + `?page=${pageNo}&size=${perPage}&sort=errorMsgId`;
    return this.http.get(serviceUrl);
  }

}
