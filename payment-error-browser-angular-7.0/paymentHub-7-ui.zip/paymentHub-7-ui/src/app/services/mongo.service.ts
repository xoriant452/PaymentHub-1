import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';

import { hostName } from '../shared/hostName';

@Injectable({
  providedIn: 'root'
})
export class MongoService {
  serviceUrl = "";
  host: string;
  mongoServiceUrl: string;
  replayUrl: string;
  getMessage: string;
  getSingleMessage: string;
  getDates: string;

  constructor(private http: HttpClient) { 
    this.host = hostName;
    this.mongoServiceUrl = this.host + "errorMessages";
    this.replayUrl = this.host +  "replayFunctionality";
    this.getMessage = this.host + "fetchSinglePaymentMessage";
    this.getSingleMessage = this.host + "singleErrorMessage";
    this.getDates = this.host + "filterDates";
  }
  
  // Returns the Observable with the list of error messages
  getErrorMessages(pageNo, perPage, date) {
    const reqParams = {
      pageNumber: pageNo,
      fromTimestamp: date,
      pageSize: perPage

    }
    return this.http.get(this.mongoServiceUrl, {params: reqParams});
  }

  // returns full single message
  getErrorMessage(messageId: number, screenName: string) {
    const fetchData = new HttpParams().set('reportName', screenName).set('errorMessageId', messageId.toString());
    return this.http.get(this.getSingleMessage, {params: fetchData});
  }

  // Replay messages, i.e the selected messages are sent for review
  replayMessages(messageList) {
    return this.http.put(this.replayUrl,messageList);
  }

  getFilteredDates() {
    return this.http.get(this.getDates);
  }

  // Returns the list of payment messages accprdomg to topic name.
  getPaymentMessage(offset: number, topicName: string) {
    const details = new HttpParams().set('offsetId', offset.toString()).set('topicName', topicName);
    return this.http.get(this.getMessage, {params: details});
  }

}