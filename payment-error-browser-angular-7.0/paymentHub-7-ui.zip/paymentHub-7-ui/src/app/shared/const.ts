export const screenNames = {
    appTitle: "Payment Hub",
    payment: "Payment Browser",
    error: "Error Browser",
    approve: "Approval",
    history: "History"
}