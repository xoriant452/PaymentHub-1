package com.citi.paymenthub.kafka.config;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.LongSerializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.citi.paymenthub.kafka.costant.ConstantUtils;
/**
 * Kafka Producer Config
 * 
 * @author Yogesh Mohite
 * @CreationDate 26/10/2018
 * @version 1.0
 */
@Component
public class KafkaProducerConfig {

	
	@Value("${spring.kafka.fetchmaxsize}")
	private Integer fetchmaxSize;
	
	@Value("${spring.kafka.consume.bootstrapServer}")
	private String bootstrapServer;


	public Map<String, Object> getProducerProperties() {
		Map<String, Object> configProps = new HashMap<>();
		configProps.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG,bootstrapServer);
		configProps.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, LongSerializer.class.getName());
		configProps.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
		configProps.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, LongSerializer.class);
		configProps.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
		configProps.put(ProducerConfig.MAX_REQUEST_SIZE_CONFIG, fetchmaxSize);
		//for testing
		configProps.put(ProducerConfig.RECONNECT_BACKOFF_MAX_MS_CONFIG, 5000);
		configProps.put(ProducerConfig.RECONNECT_BACKOFF_MS_CONFIG, 50);
		configProps.put(ProducerConfig.ACKS_CONFIG,"all");
		
		return configProps;
	}

	/**
	 * This method creates the Producer instance. 
	 * @return KafkaProducer<Long, String>
	 */
	
	public Producer<Long, String> getProducer() {
		return new KafkaProducer<>(getProducerProperties());
	}

}
